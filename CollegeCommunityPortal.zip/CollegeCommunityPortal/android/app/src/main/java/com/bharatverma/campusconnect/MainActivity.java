package com.bharatverma.campusconnect;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
