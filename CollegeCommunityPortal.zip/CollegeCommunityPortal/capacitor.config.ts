import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.bharatverma.campusconnect',
  appName: 'Campus Connect',
  webDir: 'dist/public',
  android: {
    buildOptions: {
      keystorePath: 'campus-connect.keystore',
      keystoreAlias: 'campus-connect',
    },
    overrideUserAgent: 'Campus Connect - MANIT Bhopal Student Platform',
    backgroundColor: '#FFFFFF',
    allowMixedContent: true
  },
  server: {
    androidScheme: 'https',
    url: 'https://your-repl-name.your-username.repl.co',
    cleartext: true
  }
};

export default config;
