import { pgTable, text, serial, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull().unique(),
  batch: text("batch").notNull(), // e.g., "2023 CSE"
  studentId: text("student_id"), // e.g., "2023CS0042"
  avatar: text("avatar"),
  role: text("role").default("student").notNull(), // student, alumni, faculty
  lastLogin: timestamp("last_login")
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  lastLogin: true
});

// Forum post model
export const forumPosts = pgTable("forum_posts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  userId: integer("user_id").notNull(),
  category: text("category").notNull(), // e.g., "Algorithms", "Projects", "General"
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
});

export const insertForumPostSchema = createInsertSchema(forumPosts).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

// Forum comment model
export const forumComments = pgTable("forum_comments", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  userId: integer("user_id").notNull(),
  postId: integer("post_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertForumCommentSchema = createInsertSchema(forumComments).omit({
  id: true,
  createdAt: true
});

// Resource model (for assignments, question banks, etc.)
export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  fileUrl: text("file_url").notNull(),
  fileType: text("file_type").notNull(), // e.g., "assignment", "question_bank", "note"
  category: text("category").notNull(), // subject or topic
  userId: integer("user_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertResourceSchema = createInsertSchema(resources).omit({
  id: true,
  createdAt: true
});

// Event model
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  date: timestamp("date").notNull(),
  endDate: timestamp("end_date").notNull(),
  location: text("location").notNull(),
  category: text("category").notNull(), // e.g., "Workshop", "Seminar", "Cultural"
  organizer: text("organizer").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
  createdAt: true
});

// Event RSVP model
export const eventRsvps = pgTable("event_rsvps", {
  id: serial("id").primaryKey(),
  eventId: integer("event_id").notNull(),
  userId: integer("user_id").notNull(),
  status: text("status").notNull(), // "going", "maybe", "not_going"
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertEventRsvpSchema = createInsertSchema(eventRsvps).omit({
  id: true,
  createdAt: true
});

// Bus model for campus bus tracking
export const buses = pgTable("buses", {
  id: serial("id").primaryKey(),
  busNumber: text("bus_number").notNull(),
  currentLocation: text("current_location").notNull(),
  nextStop: text("next_stop").notNull(),
  estimatedArrival: timestamp("estimated_arrival").notNull(),
  route: text("route").notNull(),
  inService: boolean("in_service").default(true).notNull()
});

export const insertBusSchema = createInsertSchema(buses).omit({
  id: true
});

// Attendance model
export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  subject: text("subject").notNull(),
  date: timestamp("date").defaultNow().notNull(),
  status: text("status").notNull(), // "present", "absent", "excused"
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertAttendanceSchema = createInsertSchema(attendance).omit({
  id: true,
  createdAt: true
});

// Academic progress model
export const academicProgress = pgTable("academic_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  subject: text("subject").notNull(),
  semester: text("semester").notNull(),
  grade: text("grade"),
  percentage: integer("percentage"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertAcademicProgressSchema = createInsertSchema(academicProgress).omit({
  id: true,
  createdAt: true
});

// Activity model for tracking user activities
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // "forum_post", "forum_comment", "resource_upload", "event_rsvp"
  data: jsonb("data").notNull(), // Store relevant data based on activity type
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true
});

// Assignment model
export const assignments = pgTable("assignments", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  dueDate: timestamp("due_date").notNull(),
  subject: text("subject").notNull(),
  department: text("department").notNull(), // Department code (cse, ece, etc.)
  batch: text("batch").notNull(), // Year of the batch
  section: text("section"), // Optional section (A, B, C, etc.)
  createdBy: integer("created_by").notNull(), // Faculty user ID
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const insertAssignmentSchema = createInsertSchema(assignments).omit({
  id: true,
  createdAt: true
});

// Assignment submission model
export const assignmentSubmissions = pgTable("assignment_submissions", {
  id: serial("id").primaryKey(),
  assignmentId: integer("assignment_id").notNull(),
  userId: integer("user_id").notNull(),
  fileUrl: text("file_url").notNull(),
  submittedAt: timestamp("submitted_at").defaultNow().notNull(),
  status: text("status").default("submitted").notNull(), // "submitted", "graded", "late"
  feedback: text("feedback"),
  grade: text("grade")
});

export const insertAssignmentSubmissionSchema = createInsertSchema(assignmentSubmissions).omit({
  id: true,
  submittedAt: true
});

// Type exports
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertForumPost = z.infer<typeof insertForumPostSchema>;
export type ForumPost = typeof forumPosts.$inferSelect;

export type InsertForumComment = z.infer<typeof insertForumCommentSchema>;
export type ForumComment = typeof forumComments.$inferSelect;

export type InsertResource = z.infer<typeof insertResourceSchema>;
export type Resource = typeof resources.$inferSelect;

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;

export type InsertEventRsvp = z.infer<typeof insertEventRsvpSchema>;
export type EventRsvp = typeof eventRsvps.$inferSelect;

export type InsertBus = z.infer<typeof insertBusSchema>;
export type Bus = typeof buses.$inferSelect;

export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type Attendance = typeof attendance.$inferSelect;

export type InsertAcademicProgress = z.infer<typeof insertAcademicProgressSchema>;
export type AcademicProgress = typeof academicProgress.$inferSelect;

export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;

export type InsertAssignment = z.infer<typeof insertAssignmentSchema>;
export type Assignment = typeof assignments.$inferSelect;

export type InsertAssignmentSubmission = z.infer<typeof insertAssignmentSubmissionSchema>;
export type AssignmentSubmission = typeof assignmentSubmissions.$inferSelect;
