import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { 
  insertForumPostSchema,
  insertForumCommentSchema,
  insertResourceSchema,
  insertEventSchema, 
  insertEventRsvpSchema,
  insertAttendanceSchema,
  insertAcademicProgressSchema,
  insertAssignmentSchema,
  insertAssignmentSubmissionSchema
} from "@shared/schema";
import { formatISO } from "date-fns";

// Middleware to check if user is authenticated
const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes (register, login, logout, user)
  setupAuth(app);

  // Forum routes
  app.get("/api/forums", async (req, res) => {
    try {
      const category = req.query.category as string | undefined;
      const posts = category 
        ? await storage.getForumPostsByCategory(category)
        : await storage.getForumPosts();
      
      // Enhance posts with user data
      const enhancedPosts = await Promise.all(
        posts.map(async (post) => {
          const user = await storage.getUser(post.userId);
          return {
            ...post,
            user: user ? {
              id: user.id,
              username: user.username,
              firstName: user.firstName,
              lastName: user.lastName,
              batch: user.batch,
              avatar: user.avatar
            } : undefined
          };
        })
      );
      
      res.json(enhancedPosts);
    } catch (error) {
      res.status(500).json({ message: "Error fetching forum posts" });
    }
  });

  app.get("/api/forums/:id", async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const post = await storage.getForumPostById(postId);
      
      if (!post) {
        return res.status(404).json({ message: "Forum post not found" });
      }
      
      const user = await storage.getUser(post.userId);
      const comments = await storage.getForumCommentsByPost(postId);
      
      // Enhance comments with user data
      const enhancedComments = await Promise.all(
        comments.map(async (comment) => {
          const commentUser = await storage.getUser(comment.userId);
          return {
            ...comment,
            user: commentUser ? {
              id: commentUser.id,
              username: commentUser.username,
              firstName: commentUser.firstName,
              lastName: commentUser.lastName,
              batch: commentUser.batch,
              avatar: commentUser.avatar
            } : undefined
          };
        })
      );
      
      res.json({
        ...post,
        user: user ? {
          id: user.id,
          username: user.username,
          firstName: user.firstName,
          lastName: user.lastName,
          batch: user.batch,
          avatar: user.avatar
        } : undefined,
        comments: enhancedComments
      });
    } catch (error) {
      res.status(500).json({ message: "Error fetching forum post" });
    }
  });

  app.post("/api/forums", isAuthenticated, async (req, res) => {
    try {
      const result = insertForumPostSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ message: "Invalid forum post data", errors: result.error.format() });
      }
      
      const post = await storage.createForumPost({
        ...result.data,
        userId: req.user.id
      });
      
      // Create activity
      await storage.createActivity({
        userId: req.user.id,
        type: "forum_post",
        data: { postId: post.id, title: post.title }
      });
      
      res.status(201).json(post);
    } catch (error) {
      res.status(500).json({ message: "Error creating forum post" });
    }
  });

  app.post("/api/forums/:id/comments", isAuthenticated, async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const post = await storage.getForumPostById(postId);
      
      if (!post) {
        return res.status(404).json({ message: "Forum post not found" });
      }
      
      const result = insertForumCommentSchema.safeParse({ ...req.body, postId });
      
      if (!result.success) {
        return res.status(400).json({ message: "Invalid comment data", errors: result.error.format() });
      }
      
      const comment = await storage.createForumComment({
        ...result.data,
        userId: req.user.id
      });
      
      // Create activity
      await storage.createActivity({
        userId: req.user.id,
        type: "forum_comment",
        data: { postId, commentId: comment.id }
      });
      
      const user = await storage.getUser(comment.userId);
      
      res.status(201).json({
        ...comment,
        user: user ? {
          id: user.id,
          username: user.username,
          firstName: user.firstName,
          lastName: user.lastName,
          batch: user.batch,
          avatar: user.avatar
        } : undefined
      });
    } catch (error) {
      res.status(500).json({ message: "Error creating comment" });
    }
  });

  // Resource routes
  app.get("/api/resources", async (req, res) => {
    try {
      const category = req.query.category as string | undefined;
      const fileType = req.query.type as string | undefined;
      
      let resources;
      if (category) {
        resources = await storage.getResourcesByCategory(category);
      } else if (fileType) {
        resources = await storage.getResourcesByType(fileType);
      } else {
        resources = await storage.getResources();
      }
      
      // Enhance resources with user data
      const enhancedResources = await Promise.all(
        resources.map(async (resource) => {
          const user = await storage.getUser(resource.userId);
          return {
            ...resource,
            user: user ? {
              id: user.id,
              username: user.username,
              firstName: user.firstName,
              lastName: user.lastName,
              batch: user.batch
            } : undefined
          };
        })
      );
      
      res.json(enhancedResources);
    } catch (error) {
      res.status(500).json({ message: "Error fetching resources" });
    }
  });

  app.get("/api/resources/:id", async (req, res) => {
    try {
      const resourceId = parseInt(req.params.id);
      const resource = await storage.getResourceById(resourceId);
      
      if (!resource) {
        return res.status(404).json({ message: "Resource not found" });
      }
      
      const user = await storage.getUser(resource.userId);
      
      res.json({
        ...resource,
        user: user ? {
          id: user.id,
          username: user.username,
          firstName: user.firstName,
          lastName: user.lastName,
          batch: user.batch
        } : undefined
      });
    } catch (error) {
      res.status(500).json({ message: "Error fetching resource" });
    }
  });

  app.post("/api/resources", isAuthenticated, async (req, res) => {
    try {
      const result = insertResourceSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ message: "Invalid resource data", errors: result.error.format() });
      }
      
      const resource = await storage.createResource({
        ...result.data,
        userId: req.user.id
      });
      
      // Create activity
      await storage.createActivity({
        userId: req.user.id,
        type: "resource_upload",
        data: { resourceId: resource.id, title: resource.title, fileType: resource.fileType }
      });
      
      res.status(201).json(resource);
    } catch (error) {
      res.status(500).json({ message: "Error creating resource" });
    }
  });

  // Event routes
  app.get("/api/events", async (req, res) => {
    try {
      const upcoming = req.query.upcoming === "true";
      const category = req.query.category as string | undefined;
      
      let events;
      if (upcoming) {
        events = await storage.getUpcomingEvents();
      } else if (category) {
        events = await storage.getEventsByCategory(category);
      } else {
        events = await storage.getEvents();
      }
      
      res.json(events);
    } catch (error) {
      res.status(500).json({ message: "Error fetching events" });
    }
  });

  app.get("/api/events/:id", async (req, res) => {
    try {
      const eventId = parseInt(req.params.id);
      const event = await storage.getEventById(eventId);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      res.json(event);
    } catch (error) {
      res.status(500).json({ message: "Error fetching event" });
    }
  });

  app.post("/api/events", isAuthenticated, async (req, res) => {
    try {
      const result = insertEventSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ message: "Invalid event data", errors: result.error.format() });
      }
      
      const event = await storage.createEvent(result.data);
      
      res.status(201).json(event);
    } catch (error) {
      res.status(500).json({ message: "Error creating event" });
    }
  });

  app.post("/api/events/:id/rsvp", isAuthenticated, async (req, res) => {
    try {
      const eventId = parseInt(req.params.id);
      const event = await storage.getEventById(eventId);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      const result = insertEventRsvpSchema.safeParse({
        ...req.body,
        eventId,
        userId: req.user.id
      });
      
      if (!result.success) {
        return res.status(400).json({ message: "Invalid RSVP data", errors: result.error.format() });
      }
      
      const rsvp = await storage.createEventRsvp(result.data);
      
      // Create activity
      await storage.createActivity({
        userId: req.user.id,
        type: "event_rsvp",
        data: { eventId, eventTitle: event.title, status: rsvp.status }
      });
      
      res.status(201).json(rsvp);
    } catch (error) {
      res.status(500).json({ message: "Error creating RSVP" });
    }
  });

  // Bus routes
  app.get("/api/buses", async (req, res) => {
    try {
      const buses = await storage.getBuses();
      res.json(buses);
    } catch (error) {
      res.status(500).json({ message: "Error fetching bus information" });
    }
  });

  app.get("/api/buses/:id", async (req, res) => {
    try {
      const busId = parseInt(req.params.id);
      const bus = await storage.getBusById(busId);
      
      if (!bus) {
        return res.status(404).json({ message: "Bus not found" });
      }
      
      res.json(bus);
    } catch (error) {
      res.status(500).json({ message: "Error fetching bus information" });
    }
  });

  // Attendance routes
  app.get("/api/attendance", isAuthenticated, async (req, res) => {
    try {
      const subject = req.query.subject as string | undefined;
      
      const attendance = subject
        ? await storage.getAttendanceByUserAndSubject(req.user.id, subject)
        : await storage.getAttendanceByUser(req.user.id);
      
      res.json(attendance);
    } catch (error) {
      res.status(500).json({ message: "Error fetching attendance records" });
    }
  });

  app.post("/api/attendance", isAuthenticated, async (req, res) => {
    try {
      const result = insertAttendanceSchema.safeParse({
        ...req.body,
        userId: req.user.id
      });
      
      if (!result.success) {
        return res.status(400).json({ message: "Invalid attendance data", errors: result.error.format() });
      }
      
      const attendance = await storage.createAttendance(result.data);
      res.status(201).json(attendance);
    } catch (error) {
      res.status(500).json({ message: "Error creating attendance record" });
    }
  });

  // Academic progress routes
  app.get("/api/academic-progress", isAuthenticated, async (req, res) => {
    try {
      const semester = req.query.semester as string | undefined;
      
      const progress = semester
        ? await storage.getAcademicProgressByUserAndSemester(req.user.id, semester)
        : await storage.getAcademicProgressByUser(req.user.id);
      
      res.json(progress);
    } catch (error) {
      res.status(500).json({ message: "Error fetching academic progress" });
    }
  });

  app.post("/api/academic-progress", isAuthenticated, async (req, res) => {
    try {
      const result = insertAcademicProgressSchema.safeParse({
        ...req.body,
        userId: req.user.id
      });
      
      if (!result.success) {
        return res.status(400).json({ message: "Invalid academic progress data", errors: result.error.format() });
      }
      
      const progress = await storage.createAcademicProgress(result.data);
      res.status(201).json(progress);
    } catch (error) {
      res.status(500).json({ message: "Error creating academic progress record" });
    }
  });

  // Activity routes
  app.get("/api/activities", isAuthenticated, async (req, res) => {
    try {
      const activities = await storage.getActivitiesByUser(req.user.id);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Error fetching activities" });
    }
  });

  app.get("/api/activities/recent", isAuthenticated, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string || "10");
      const activities = await storage.getRecentActivities(limit);
      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Error fetching recent activities" });
    }
  });

  // Assignment routes
  app.get("/api/assignments", async (req, res) => {
    try {
      const subject = req.query.subject as string | undefined;
      const pending = req.query.pending === "true";
      
      let assignments;
      if (subject) {
        assignments = await storage.getAssignmentsBySubject(subject);
      } else if (pending) {
        assignments = await storage.getPendingAssignments();
      } else {
        assignments = await storage.getAssignments();
      }
      
      res.json(assignments);
    } catch (error) {
      res.status(500).json({ message: "Error fetching assignments" });
    }
  });

  app.get("/api/assignments/:id", async (req, res) => {
    try {
      const assignmentId = parseInt(req.params.id);
      const assignment = await storage.getAssignmentById(assignmentId);
      
      if (!assignment) {
        return res.status(404).json({ message: "Assignment not found" });
      }
      
      res.json(assignment);
    } catch (error) {
      res.status(500).json({ message: "Error fetching assignment" });
    }
  });

  app.post("/api/assignments", isAuthenticated, async (req, res) => {
    try {
      const result = insertAssignmentSchema.safeParse({
        ...req.body,
        createdBy: req.user.id
      });
      
      if (!result.success) {
        return res.status(400).json({ message: "Invalid assignment data", errors: result.error.format() });
      }
      
      const assignment = await storage.createAssignment(result.data);
      res.status(201).json(assignment);
    } catch (error) {
      res.status(500).json({ message: "Error creating assignment" });
    }
  });

  app.post("/api/assignments/:id/submit", isAuthenticated, async (req, res) => {
    try {
      const assignmentId = parseInt(req.params.id);
      const assignment = await storage.getAssignmentById(assignmentId);
      
      if (!assignment) {
        return res.status(404).json({ message: "Assignment not found" });
      }
      
      const result = insertAssignmentSubmissionSchema.safeParse({
        ...req.body,
        assignmentId,
        userId: req.user.id
      });
      
      if (!result.success) {
        return res.status(400).json({ message: "Invalid submission data", errors: result.error.format() });
      }
      
      // Check if submission is late
      const now = new Date();
      const status = now > assignment.dueDate ? "late" : "submitted";
      
      const submission = await storage.createAssignmentSubmission({
        ...result.data,
        status
      });
      
      // Create activity
      await storage.createActivity({
        userId: req.user.id,
        type: "assignment_submission",
        data: { assignmentId, assignmentTitle: assignment.title, status }
      });
      
      res.status(201).json(submission);
    } catch (error) {
      res.status(500).json({ message: "Error submitting assignment" });
    }
  });

  app.get("/api/assignments/submissions/user", isAuthenticated, async (req, res) => {
    try {
      const submissions = await storage.getAssignmentSubmissionsByUser(req.user.id);
      
      // Enhance submissions with assignment data
      const enhancedSubmissions = await Promise.all(
        submissions.map(async (submission) => {
          const assignment = await storage.getAssignmentById(submission.assignmentId);
          return {
            ...submission,
            assignment
          };
        })
      );
      
      res.json(enhancedSubmissions);
    } catch (error) {
      res.status(500).json({ message: "Error fetching submissions" });
    }
  });

  // Initialize HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
