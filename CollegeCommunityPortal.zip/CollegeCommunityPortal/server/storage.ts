import { 
  users, type User, type InsertUser,
  forumPosts, type ForumPost, type InsertForumPost,
  forumComments, type ForumComment, type InsertForumComment,
  resources, type Resource, type InsertResource,
  events, type Event, type InsertEvent,
  eventRsvps, type EventRsvp, type InsertEventRsvp,
  buses, type Bus, type InsertBus,
  attendance, type Attendance, type InsertAttendance,
  academicProgress, type AcademicProgress, type InsertAcademicProgress,
  activities, type Activity, type InsertActivity,
  assignments, type Assignment, type InsertAssignment,
  assignmentSubmissions, type AssignmentSubmission, type InsertAssignmentSubmission
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUsersByBatch(batch: string): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUserLastLogin(id: number): Promise<User | undefined>;
  
  // Forum operations
  createForumPost(post: InsertForumPost): Promise<ForumPost>;
  getForumPosts(): Promise<ForumPost[]>;
  getForumPostById(id: number): Promise<ForumPost | undefined>;
  getForumPostsByCategory(category: string): Promise<ForumPost[]>;
  getForumPostsByUser(userId: number): Promise<ForumPost[]>;
  
  // Forum comment operations
  createForumComment(comment: InsertForumComment): Promise<ForumComment>;
  getForumCommentsByPost(postId: number): Promise<ForumComment[]>;
  
  // Resource operations
  createResource(resource: InsertResource): Promise<Resource>;
  getResources(): Promise<Resource[]>;
  getResourceById(id: number): Promise<Resource | undefined>;
  getResourcesByCategory(category: string): Promise<Resource[]>;
  getResourcesByType(fileType: string): Promise<Resource[]>;
  getResourcesByUser(userId: number): Promise<Resource[]>;
  
  // Event operations
  createEvent(event: InsertEvent): Promise<Event>;
  getEvents(): Promise<Event[]>;
  getEventById(id: number): Promise<Event | undefined>;
  getUpcomingEvents(): Promise<Event[]>;
  getEventsByCategory(category: string): Promise<Event[]>;
  
  // Event RSVP operations
  createEventRsvp(rsvp: InsertEventRsvp): Promise<EventRsvp>;
  getEventRsvpsByEvent(eventId: number): Promise<EventRsvp[]>;
  getEventRsvpsByUser(userId: number): Promise<EventRsvp[]>;
  
  // Bus operations
  getBuses(): Promise<Bus[]>;
  getBusById(id: number): Promise<Bus | undefined>;
  updateBusLocation(id: number, location: string, nextStop: string, estimatedArrival: Date): Promise<Bus | undefined>;
  
  // Attendance operations
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  getAttendanceByUser(userId: number): Promise<Attendance[]>;
  getAttendanceByUserAndSubject(userId: number, subject: string): Promise<Attendance[]>;
  
  // Academic progress operations
  createAcademicProgress(progress: InsertAcademicProgress): Promise<AcademicProgress>;
  getAcademicProgressByUser(userId: number): Promise<AcademicProgress[]>;
  getAcademicProgressByUserAndSemester(userId: number, semester: string): Promise<AcademicProgress[]>;
  
  // Activity operations
  createActivity(activity: InsertActivity): Promise<Activity>;
  getActivitiesByUser(userId: number): Promise<Activity[]>;
  getRecentActivities(limit: number): Promise<Activity[]>;
  
  // Assignment operations
  createAssignment(assignment: InsertAssignment): Promise<Assignment>;
  getAssignments(): Promise<Assignment[]>;
  getAssignmentById(id: number): Promise<Assignment | undefined>;
  getAssignmentsBySubject(subject: string): Promise<Assignment[]>;
  getPendingAssignments(): Promise<Assignment[]>;
  
  // Assignment submission operations
  createAssignmentSubmission(submission: InsertAssignmentSubmission): Promise<AssignmentSubmission>;
  getAssignmentSubmissionsByAssignment(assignmentId: number): Promise<AssignmentSubmission[]>;
  getAssignmentSubmissionsByUser(userId: number): Promise<AssignmentSubmission[]>;
  
  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private forumPosts: Map<number, ForumPost>;
  private forumComments: Map<number, ForumComment>;
  private resources: Map<number, Resource>;
  private events: Map<number, Event>;
  private eventRsvps: Map<number, EventRsvp>;
  private buses: Map<number, Bus>;
  private attendanceRecords: Map<number, Attendance>;
  private academicProgressRecords: Map<number, AcademicProgress>;
  private activities: Map<number, Activity>;
  private assignments: Map<number, Assignment>;
  private assignmentSubmissions: Map<number, AssignmentSubmission>;
  
  sessionStore: session.SessionStore;
  
  private userIdCounter: number;
  private postIdCounter: number;
  private commentIdCounter: number;
  private resourceIdCounter: number;
  private eventIdCounter: number;
  private rsvpIdCounter: number;
  private busIdCounter: number;
  private attendanceIdCounter: number;
  private progressIdCounter: number;
  private activityIdCounter: number;
  private assignmentIdCounter: number;
  private submissionIdCounter: number;

  constructor() {
    this.users = new Map();
    this.forumPosts = new Map();
    this.forumComments = new Map();
    this.resources = new Map();
    this.events = new Map();
    this.eventRsvps = new Map();
    this.buses = new Map();
    this.attendanceRecords = new Map();
    this.academicProgressRecords = new Map();
    this.activities = new Map();
    this.assignments = new Map();
    this.assignmentSubmissions = new Map();
    
    this.userIdCounter = 1;
    this.postIdCounter = 1;
    this.commentIdCounter = 1;
    this.resourceIdCounter = 1;
    this.eventIdCounter = 1;
    this.rsvpIdCounter = 1;
    this.busIdCounter = 1;
    this.attendanceIdCounter = 1;
    this.progressIdCounter = 1;
    this.activityIdCounter = 1;
    this.assignmentIdCounter = 1;
    this.submissionIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
    
    // Initialize with some demo data for buses
    this.initializeDemoData();
  }
  
  private initializeDemoData() {
    // Add some bus data for the bus tracker
    this.buses.set(1, {
      id: 1,
      busNumber: "102",
      currentLocation: "Main Gate",
      nextStop: "CS Building",
      estimatedArrival: new Date(Date.now() + 5 * 60 * 1000), // 5 mins from now
      route: "Campus Loop",
      inService: true
    });
    
    this.buses.set(2, {
      id: 2,
      busNumber: "104",
      currentLocation: "Library",
      nextStop: "Student Center",
      estimatedArrival: new Date(Date.now() + 12 * 60 * 1000), // 12 mins from now
      route: "City Connector",
      inService: true
    });
    
    this.busIdCounter = 3;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.username.toLowerCase() === username.toLowerCase()) {
        return user;
      }
    }
    return undefined;
  }
  
  async getUsersByBatch(batch: string): Promise<User[]> {
    const batchUsers: User[] = [];
    for (const user of this.users.values()) {
      if (user.batch === batch) {
        batchUsers.push(user);
      }
    }
    return batchUsers;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { ...insertUser, id, lastLogin: now };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserLastLogin(id: number): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (user) {
      user.lastLogin = new Date();
      this.users.set(id, user);
      return user;
    }
    return undefined;
  }

  // Forum operations
  async createForumPost(post: InsertForumPost): Promise<ForumPost> {
    const id = this.postIdCounter++;
    const now = new Date();
    const forumPost: ForumPost = { ...post, id, createdAt: now, updatedAt: now };
    this.forumPosts.set(id, forumPost);
    return forumPost;
  }

  async getForumPosts(): Promise<ForumPost[]> {
    return Array.from(this.forumPosts.values()).sort((a, b) => 
      b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async getForumPostById(id: number): Promise<ForumPost | undefined> {
    return this.forumPosts.get(id);
  }

  async getForumPostsByCategory(category: string): Promise<ForumPost[]> {
    return Array.from(this.forumPosts.values())
      .filter(post => post.category === category)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getForumPostsByUser(userId: number): Promise<ForumPost[]> {
    return Array.from(this.forumPosts.values())
      .filter(post => post.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // Forum comment operations
  async createForumComment(comment: InsertForumComment): Promise<ForumComment> {
    const id = this.commentIdCounter++;
    const now = new Date();
    const forumComment: ForumComment = { ...comment, id, createdAt: now };
    this.forumComments.set(id, forumComment);
    return forumComment;
  }

  async getForumCommentsByPost(postId: number): Promise<ForumComment[]> {
    return Array.from(this.forumComments.values())
      .filter(comment => comment.postId === postId)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  // Resource operations
  async createResource(resource: InsertResource): Promise<Resource> {
    const id = this.resourceIdCounter++;
    const now = new Date();
    const newResource: Resource = { ...resource, id, createdAt: now };
    this.resources.set(id, newResource);
    return newResource;
  }

  async getResources(): Promise<Resource[]> {
    return Array.from(this.resources.values()).sort((a, b) => 
      b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async getResourceById(id: number): Promise<Resource | undefined> {
    return this.resources.get(id);
  }

  async getResourcesByCategory(category: string): Promise<Resource[]> {
    return Array.from(this.resources.values())
      .filter(resource => resource.category === category)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getResourcesByType(fileType: string): Promise<Resource[]> {
    return Array.from(this.resources.values())
      .filter(resource => resource.fileType === fileType)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getResourcesByUser(userId: number): Promise<Resource[]> {
    return Array.from(this.resources.values())
      .filter(resource => resource.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // Event operations
  async createEvent(event: InsertEvent): Promise<Event> {
    const id = this.eventIdCounter++;
    const now = new Date();
    const newEvent: Event = { ...event, id, createdAt: now };
    this.events.set(id, newEvent);
    return newEvent;
  }

  async getEvents(): Promise<Event[]> {
    return Array.from(this.events.values()).sort((a, b) => 
      a.date.getTime() - b.date.getTime()
    );
  }

  async getEventById(id: number): Promise<Event | undefined> {
    return this.events.get(id);
  }

  async getUpcomingEvents(): Promise<Event[]> {
    const now = new Date();
    return Array.from(this.events.values())
      .filter(event => event.date > now)
      .sort((a, b) => a.date.getTime() - b.date.getTime());
  }

  async getEventsByCategory(category: string): Promise<Event[]> {
    return Array.from(this.events.values())
      .filter(event => event.category === category)
      .sort((a, b) => a.date.getTime() - b.date.getTime());
  }

  // Event RSVP operations
  async createEventRsvp(rsvp: InsertEventRsvp): Promise<EventRsvp> {
    const id = this.rsvpIdCounter++;
    const now = new Date();
    const newRsvp: EventRsvp = { ...rsvp, id, createdAt: now };
    this.eventRsvps.set(id, newRsvp);
    return newRsvp;
  }

  async getEventRsvpsByEvent(eventId: number): Promise<EventRsvp[]> {
    return Array.from(this.eventRsvps.values())
      .filter(rsvp => rsvp.eventId === eventId);
  }

  async getEventRsvpsByUser(userId: number): Promise<EventRsvp[]> {
    return Array.from(this.eventRsvps.values())
      .filter(rsvp => rsvp.userId === userId);
  }

  // Bus operations
  async getBuses(): Promise<Bus[]> {
    return Array.from(this.buses.values());
  }

  async getBusById(id: number): Promise<Bus | undefined> {
    return this.buses.get(id);
  }

  async updateBusLocation(
    id: number, 
    location: string, 
    nextStop: string, 
    estimatedArrival: Date
  ): Promise<Bus | undefined> {
    const bus = await this.getBusById(id);
    if (bus) {
      bus.currentLocation = location;
      bus.nextStop = nextStop;
      bus.estimatedArrival = estimatedArrival;
      this.buses.set(id, bus);
      return bus;
    }
    return undefined;
  }

  // Attendance operations
  async createAttendance(attendanceRecord: InsertAttendance): Promise<Attendance> {
    const id = this.attendanceIdCounter++;
    const now = new Date();
    const newAttendance: Attendance = { ...attendanceRecord, id, createdAt: now };
    this.attendanceRecords.set(id, newAttendance);
    return newAttendance;
  }

  async getAttendanceByUser(userId: number): Promise<Attendance[]> {
    return Array.from(this.attendanceRecords.values())
      .filter(record => record.userId === userId)
      .sort((a, b) => b.date.getTime() - a.date.getTime());
  }

  async getAttendanceByUserAndSubject(userId: number, subject: string): Promise<Attendance[]> {
    return Array.from(this.attendanceRecords.values())
      .filter(record => record.userId === userId && record.subject === subject)
      .sort((a, b) => b.date.getTime() - a.date.getTime());
  }

  // Academic progress operations
  async createAcademicProgress(progress: InsertAcademicProgress): Promise<AcademicProgress> {
    const id = this.progressIdCounter++;
    const now = new Date();
    const newProgress: AcademicProgress = { ...progress, id, createdAt: now };
    this.academicProgressRecords.set(id, newProgress);
    return newProgress;
  }

  async getAcademicProgressByUser(userId: number): Promise<AcademicProgress[]> {
    return Array.from(this.academicProgressRecords.values())
      .filter(record => record.userId === userId);
  }

  async getAcademicProgressByUserAndSemester(userId: number, semester: string): Promise<AcademicProgress[]> {
    return Array.from(this.academicProgressRecords.values())
      .filter(record => record.userId === userId && record.semester === semester);
  }

  // Activity operations
  async createActivity(activity: InsertActivity): Promise<Activity> {
    const id = this.activityIdCounter++;
    const now = new Date();
    const newActivity: Activity = { ...activity, id, createdAt: now };
    this.activities.set(id, newActivity);
    return newActivity;
  }

  async getActivitiesByUser(userId: number): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .filter(activity => activity.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getRecentActivities(limit: number): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  // Assignment operations
  async createAssignment(assignment: InsertAssignment): Promise<Assignment> {
    const id = this.assignmentIdCounter++;
    const now = new Date();
    const newAssignment: Assignment = { ...assignment, id, createdAt: now };
    this.assignments.set(id, newAssignment);
    return newAssignment;
  }

  async getAssignments(): Promise<Assignment[]> {
    return Array.from(this.assignments.values()).sort((a, b) => 
      a.dueDate.getTime() - b.dueDate.getTime()
    );
  }

  async getAssignmentById(id: number): Promise<Assignment | undefined> {
    return this.assignments.get(id);
  }

  async getAssignmentsBySubject(subject: string): Promise<Assignment[]> {
    return Array.from(this.assignments.values())
      .filter(assignment => assignment.subject === subject)
      .sort((a, b) => a.dueDate.getTime() - b.dueDate.getTime());
  }

  async getPendingAssignments(): Promise<Assignment[]> {
    const now = new Date();
    return Array.from(this.assignments.values())
      .filter(assignment => assignment.dueDate > now)
      .sort((a, b) => a.dueDate.getTime() - b.dueDate.getTime());
  }

  // Assignment submission operations
  async createAssignmentSubmission(submission: InsertAssignmentSubmission): Promise<AssignmentSubmission> {
    const id = this.submissionIdCounter++;
    const now = new Date();
    const newSubmission: AssignmentSubmission = { ...submission, id, submittedAt: now };
    this.assignmentSubmissions.set(id, newSubmission);
    return newSubmission;
  }

  async getAssignmentSubmissionsByAssignment(assignmentId: number): Promise<AssignmentSubmission[]> {
    return Array.from(this.assignmentSubmissions.values())
      .filter(submission => submission.assignmentId === assignmentId)
      .sort((a, b) => b.submittedAt.getTime() - a.submittedAt.getTime());
  }

  async getAssignmentSubmissionsByUser(userId: number): Promise<AssignmentSubmission[]> {
    return Array.from(this.assignmentSubmissions.values())
      .filter(submission => submission.userId === userId)
      .sort((a, b) => b.submittedAt.getTime() - a.submittedAt.getTime());
  }
}

export const storage = new MemStorage();
