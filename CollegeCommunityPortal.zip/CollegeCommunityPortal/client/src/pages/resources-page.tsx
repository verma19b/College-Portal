import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ResourceCard } from "@/components/resources/resource-card";
import { UploadResourceDialog } from "@/components/resources/upload-resource-dialog";
import { AppShell } from "@/components/layout/app-shell";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Laptop, Cpu, Bolt, Wrench, Building2, Beaker, Factory } from "lucide-react";

// MANIT Bhopal departments with icons
const departments = [
  { id: "all", name: "All Departments", icon: <Building2 className="h-4 w-4" /> },
  { id: "cse", name: "Computer Science & Engineering (CSE)", icon: <Laptop className="h-4 w-4" /> },
  { id: "ece", name: "Electronics & Communication Engineering (ECE)", icon: <Cpu className="h-4 w-4" /> },
  { id: "ee", name: "Electrical Engineering (EE)", icon: <Bolt className="h-4 w-4" /> },
  { id: "me", name: "Mechanical Engineering (ME)", icon: <Wrench className="h-4 w-4" /> },
  { id: "ce", name: "Civil Engineering (CE)", icon: <Building2 className="h-4 w-4" /> },
  { id: "chem", name: "Chemical Engineering (CHEM)", icon: <Beaker className="h-4 w-4" /> },
  { id: "mme", name: "Metallurgy & Materials Engineering (MME)", icon: <Factory className="h-4 w-4" /> }
];

// Resource categories specific to MANIT Bhopal context
const categories = [
  "All",
  "First Year Common",
  "Programming",
  "Data Structures",
  "Algorithms",
  "Database Systems",
  "Web Development",
  "Machine Learning",
  "Computer Networks",
  "Electronics",
  "Circuits",
  "Power Systems",
  "Mechanical Design",
  "Thermodynamics",
  "Fluid Mechanics",
  "Structural Analysis",
  "Construction Technology",
  "Chemical Processes",
  "Material Science",
  "Metallurgy",
  "Project Report",
  "Lab Manual",
  "Other"
];

// Resource types
const resourceTypes = [
  "All Types",
  "Assignment",
  "Question Bank",
  "Note",
  "Study Material",
  "Lab Manual",
  "Presentation",
  "Previous Year Paper",
  "Syllabus",
  "Project Report"
];

// Helper to convert camelCase to Title Case
const formatResourceType = (type: string) => {
  if (type === "All Types") return type;
  return type.split('_').map(word => 
    word.charAt(0).toUpperCase() + word.slice(1)
  ).join(' ');
};

export default function ResourcesPage() {
  const [selectedDepartment, setSelectedDepartment] = useState<string>("all");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [selectedType, setSelectedType] = useState<string>("All Types");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [activeTab, setActiveTab] = useState<string>("all");
  
  // Map the display names back to API values
  const getTypeValue = (displayType: string) => {
    if (displayType === "All Types") return undefined;
    return displayType.toLowerCase().replace(/ /g, '_');
  };
  
  // Fetch resources with filters
  const { data: resources, isLoading } = useQuery({
    queryKey: [
      "/api/resources", 
      selectedCategory !== "All" ? { category: selectedCategory } : undefined,
      selectedType !== "All Types" ? { type: getTypeValue(selectedType) } : undefined
    ],
    // Using default query function
  });
  
  // Filter resources by search query, department, and type
  const filteredResources = resources?.filter((resource: any) => {
    if (!searchQuery && selectedDepartment === "all" && activeTab === "all") return true;
    
    const query = searchQuery.toLowerCase();
    const matchesSearch = !searchQuery || 
      resource.title.toLowerCase().includes(query) ||
      resource.description.toLowerCase().includes(query) ||
      resource.category.toLowerCase().includes(query);
    
    const matchesDepartment = selectedDepartment === "all" || 
      (resource.department && resource.department.toLowerCase() === selectedDepartment.toLowerCase());
    
    const matchesTab = activeTab === "all" || 
      (resource.fileType && resource.fileType.toLowerCase().includes(activeTab.replace("-", "_")));
    
    return matchesSearch && matchesDepartment && matchesTab;
  });
  
  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">MANIT Bhopal Resources</h1>
            <p className="text-neutral-600">Access study materials, assignments, and more for all departments</p>
          </div>
          
          <UploadResourceDialog />
        </div>
        
        <div className="bg-white shadow-sm rounded-lg p-6">
          {/* Department Tabs */}
          <Tabs 
            defaultValue="all" 
            className="w-full mb-6"
            value={selectedDepartment}
            onValueChange={setSelectedDepartment}
          >
            <TabsList className="mb-4 flex flex-wrap h-auto">
              {departments.map((dept) => (
                <TabsTrigger key={dept.id} value={dept.id} className="flex items-center gap-1">
                  {dept.icon}
                  <span className="hidden md:inline">{dept.name}</span>
                  <span className="inline md:hidden">{dept.id.toUpperCase()}</span>
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
          
          {/* Search & Filters */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-neutral-400" />
              </div>
              <Input
                type="text"
                placeholder="Search resources..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div className="w-full sm:w-48">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="w-full sm:w-48">
              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Resource Type" />
                </SelectTrigger>
                <SelectContent>
                  {resourceTypes.map((type) => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Resource Type Tabs */}
          <Tabs 
            value={activeTab} 
            onValueChange={setActiveTab} 
            className="w-full"
          >
            <TabsList className="mb-6">
              <TabsTrigger value="all">All Resources</TabsTrigger>
              <TabsTrigger value="assignments">Assignments</TabsTrigger>
              <TabsTrigger value="question-banks">Question Banks</TabsTrigger>
              <TabsTrigger value="notes">Notes</TabsTrigger>
              <TabsTrigger value="syllabus">Syllabus</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all" className="space-y-4">
              {isLoading ? (
                Array(5).fill(0).map((_, i) => (
                  <div key={i} className="mb-4">
                    <Skeleton className="h-[180px] w-full rounded-lg" />
                  </div>
                ))
              ) : filteredResources && filteredResources.length > 0 ? (
                filteredResources.map((resource: any) => (
                  <ResourceCard key={resource.id} resource={resource} />
                ))
              ) : (
                <div className="text-center py-8">
                  <p className="text-neutral-500">No resources found.</p>
                  {(searchQuery || selectedCategory !== "All" || selectedType !== "All Types" || selectedDepartment !== "all") && (
                    <p className="text-neutral-400 mt-2">
                      Try adjusting your search or filters.
                    </p>
                  )}
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="assignments" className="space-y-4">
              {isLoading ? (
                <div className="py-8 text-center">
                  <Skeleton className="h-6 w-32 mx-auto mb-2" />
                  <Skeleton className="h-4 w-48 mx-auto" />
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-neutral-500">
                    {selectedDepartment !== "all" 
                      ? `${departments.find(d => d.id === selectedDepartment)?.name} assignments will be shown here.`
                      : "Select a department to view specific assignments."}
                  </p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="question-banks" className="space-y-4">
              {isLoading ? (
                <div className="py-8 text-center">
                  <Skeleton className="h-6 w-32 mx-auto mb-2" />
                  <Skeleton className="h-4 w-48 mx-auto" />
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-neutral-500">
                    {selectedDepartment !== "all" 
                      ? `${departments.find(d => d.id === selectedDepartment)?.name} question banks will be shown here.`
                      : "Select a department to view specific question banks."}
                  </p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="notes" className="space-y-4">
              {isLoading ? (
                <div className="py-8 text-center">
                  <Skeleton className="h-6 w-32 mx-auto mb-2" />
                  <Skeleton className="h-4 w-48 mx-auto" />
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-neutral-500">
                    {selectedDepartment !== "all" 
                      ? `${departments.find(d => d.id === selectedDepartment)?.name} notes will be shown here.`
                      : "Select a department to view specific notes."}
                  </p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="syllabus" className="space-y-4">
              {isLoading ? (
                <div className="py-8 text-center">
                  <Skeleton className="h-6 w-32 mx-auto mb-2" />
                  <Skeleton className="h-4 w-48 mx-auto" />
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-neutral-500">
                    {selectedDepartment !== "all" 
                      ? `${departments.find(d => d.id === selectedDepartment)?.name} syllabus will be shown here.`
                      : "Select a department to view specific syllabi."}
                  </p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </AppShell>
  );
}
