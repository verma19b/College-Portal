import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/layout/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { formatDistanceToNow } from "date-fns";
import { 
  Bus, 
  Clock, 
  MapPin, 
  LocateFixed,
  Route as RouteIcon,
  ArrowRight
} from "lucide-react";

export default function BusTrackerPage() {
  // Fetch bus data
  const { data: buses, isLoading } = useQuery({
    queryKey: ["/api/buses"],
    // Using default query function
    refetchInterval: 30000, // Refetch every 30 seconds for live updates
  });
  
  return (
    <AppShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">Campus Bus Tracker</h1>
          <p className="text-neutral-600">Track campus buses in real-time and plan your commute</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className="h-full">
              <CardHeader>
                <CardTitle>Live Map</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-neutral-100 h-[400px] rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="h-12 w-12 text-neutral-300 mx-auto mb-3" />
                    <p className="text-neutral-500">Campus Map</p>
                    <p className="text-sm text-neutral-400 mt-2">Interactive campus map with bus locations will be available soon</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div>
            <Card className="h-full">
              <CardHeader>
                <CardTitle>Active Buses</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="all" className="w-full">
                  <TabsList className="mb-6">
                    <TabsTrigger value="all">All Routes</TabsTrigger>
                    <TabsTrigger value="nearby">Nearby</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="all">
                    {isLoading ? (
                      Array(3).fill(0).map((_, i) => (
                        <div key={i} className="mb-3">
                          <Skeleton className="h-24 w-full rounded-lg" />
                        </div>
                      ))
                    ) : buses && buses.length > 0 ? (
                      <div className="space-y-3">
                        {buses.map((bus: any) => {
                          const arrivalTime = new Date(bus.estimatedArrival);
                          const timeRemaining = formatDistanceToNow(arrivalTime, { addSuffix: false });
                          
                          return (
                            <div 
                              key={bus.id} 
                              className="border border-neutral-200 rounded-lg p-4 hover:bg-neutral-50 transition-colors"
                            >
                              <div className="flex items-center justify-between mb-3">
                                <div className="flex items-center">
                                  <div className="flex-shrink-0 bg-primary/10 rounded-full p-2">
                                    <Bus className="h-5 w-5 text-primary" />
                                  </div>
                                  <div className="ml-3">
                                    <h3 className="font-medium">Bus #{bus.busNumber}</h3>
                                    <p className="text-xs text-neutral-500">
                                      <RouteIcon className="h-3 w-3 inline mr-1" />
                                      {bus.route}
                                    </p>
                                  </div>
                                </div>
                                <Badge variant={bus.inService ? "outline" : "secondary"} className={bus.inService ? "bg-green-50 text-green-600 border-green-200" : ""}>
                                  {bus.inService ? "In Service" : "Out of Service"}
                                </Badge>
                              </div>
                              
                              <div className="flex items-center justify-between text-sm text-neutral-600">
                                <div className="flex items-center">
                                  <LocateFixed className="h-4 w-4 text-neutral-400 mr-1" />
                                  <span>{bus.currentLocation}</span>
                                  <ArrowRight className="h-3 w-3 mx-2" />
                                  <span>{bus.nextStop}</span>
                                </div>
                                <div className="flex items-center">
                                  <Clock className="h-4 w-4 text-neutral-400 mr-1" />
                                  <span>~{timeRemaining}</span>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="text-center py-8">
                        <Bus className="h-12 w-12 text-neutral-300 mx-auto mb-3" />
                        <p className="text-neutral-500">No buses currently in service.</p>
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="nearby">
                    <div className="text-center py-8">
                      <LocateFixed className="h-12 w-12 text-neutral-300 mx-auto mb-3" />
                      <p className="text-neutral-500">Nearby buses will be shown here.</p>
                      <p className="text-sm text-neutral-400 mt-2">Enable location services for this feature</p>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Bus Routes & Schedules</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="campus-loop" className="w-full">
              <TabsList className="mb-6">
                <TabsTrigger value="campus-loop">Campus Loop</TabsTrigger>
                <TabsTrigger value="city-connector">City Connector</TabsTrigger>
                <TabsTrigger value="express">Express Route</TabsTrigger>
              </TabsList>
              
              <TabsContent value="campus-loop">
                <div className="rounded-md border p-4">
                  <h3 className="font-medium text-lg mb-2">Campus Loop Route</h3>
                  <p className="text-neutral-600 mb-4">
                    This route circles the main campus, stopping at all major buildings and facilities.
                  </p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium mb-2">Stops</h4>
                      <ul className="space-y-2">
                        <li className="flex items-center">
                          <MapPin className="h-4 w-4 text-primary mr-2" />
                          <span>Main Gate</span>
                        </li>
                        <li className="flex items-center">
                          <MapPin className="h-4 w-4 text-primary mr-2" />
                          <span>Student Center</span>
                        </li>
                        <li className="flex items-center">
                          <MapPin className="h-4 w-4 text-primary mr-2" />
                          <span>Library</span>
                        </li>
                        <li className="flex items-center">
                          <MapPin className="h-4 w-4 text-primary mr-2" />
                          <span>CS Building</span>
                        </li>
                        <li className="flex items-center">
                          <MapPin className="h-4 w-4 text-primary mr-2" />
                          <span>Engineering Block</span>
                        </li>
                        <li className="flex items-center">
                          <MapPin className="h-4 w-4 text-primary mr-2" />
                          <span>Hostel Area</span>
                        </li>
                      </ul>
                    </div>
                    
                    <div>
                      <h4 className="font-medium mb-2">Schedule</h4>
                      <ul className="space-y-2">
                        <li className="flex items-center">
                          <Clock className="h-4 w-4 text-primary mr-2" />
                          <span>Weekdays: 7:00 AM - 9:00 PM (every 15 mins)</span>
                        </li>
                        <li className="flex items-center">
                          <Clock className="h-4 w-4 text-primary mr-2" />
                          <span>Weekends: 8:00 AM - 6:00 PM (every 30 mins)</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="city-connector">
                <div className="text-center py-8">
                  <RouteIcon className="h-12 w-12 text-neutral-300 mx-auto mb-3" />
                  <p className="text-neutral-500">City Connector route details will be shown here.</p>
                </div>
              </TabsContent>
              
              <TabsContent value="express">
                <div className="text-center py-8">
                  <RouteIcon className="h-12 w-12 text-neutral-300 mx-auto mb-3" />
                  <p className="text-neutral-500">Express route details will be shown here.</p>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}
