import { useState } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Search, Mail, Briefcase, Calendar, MapPin, School } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { getInitials } from "@/lib/utils";

// Mock data for alumni - in a real implementation, this would come from the API
const seniors = [
  {
    id: 1,
    name: "Michael Torres",
    batch: "2021 CSE",
    position: "Software Engineer @ Google",
    location: "San Francisco, CA",
    avatar: "",
    skills: ["React", "Node.js", "AWS"],
    bio: "Working on search infrastructure at Google. Previously interned at Microsoft. Happy to help with interview preparation and resume reviews.",
  },
  {
    id: 2,
    name: "Priya Sharma",
    batch: "2020 CSE",
    position: "ML Engineer @ Microsoft",
    location: "Bangalore, India",
    avatar: "",
    skills: ["Python", "TensorFlow", "Computer Vision"],
    bio: "Machine Learning Engineer focusing on computer vision applications. Passionate about AI ethics and responsible deployment of ML systems.",
  },
  {
    id: 3,
    name: "David Kim",
    batch: "2021 CSE",
    position: "Product Manager @ Amazon",
    location: "Seattle, WA",
    avatar: "",
    skills: ["Product Strategy", "UX Design", "Data Analysis"],
    bio: "Product Manager at Amazon working on retail tech. Graduated with a CS degree but pivoted to product management. Happy to discuss PM career paths.",
  },
  {
    id: 4,
    name: "Sarah Johnson",
    batch: "2019 ECE",
    position: "Hardware Engineer @ Apple",
    location: "Cupertino, CA",
    avatar: "",
    skills: ["Hardware Design", "Embedded Systems", "IoT"],
    bio: "Working on next-gen Apple hardware. Specialized in embedded systems and IoT during college. Open to mentoring ECE students.",
  },
  {
    id: 5,
    name: "Raj Patel",
    batch: "2020 CSE",
    position: "Backend Engineer @ Netflix",
    location: "Los Angeles, CA",
    avatar: "",
    skills: ["Java", "Microservices", "Distributed Systems"],
    bio: "Backend engineer at Netflix working on content delivery systems. Passionate about distributed systems and high-scale architecture.",
  },
  {
    id: 6,
    name: "Emma Wilson",
    batch: "2022 CSE",
    position: "Data Scientist @ Spotify",
    location: "Stockholm, Sweden",
    avatar: "",
    skills: ["Python", "R", "Data Visualization"],
    bio: "Recent graduate working as a Data Scientist at Spotify. Happy to discuss transitioning from academics to industry.",
  },
];

// Department options
const departments = [
  "All Departments",
  "CSE",
  "ECE",
  "ME",
  "CE",
  "EE",
  "IT",
  "BT",
  "CH"
];

// Batch year options
const batchYears = [
  "All Years",
  "2023",
  "2022",
  "2021",
  "2020",
  "2019",
  "2018"
];

export default function ConnectPage() {
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedDepartment, setSelectedDepartment] = useState<string>("All Departments");
  const [selectedYear, setSelectedYear] = useState<string>("All Years");
  
  // Filter seniors by search query and filters
  const filteredSeniors = seniors.filter((senior) => {
    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      if (
        !senior.name.toLowerCase().includes(query) &&
        !senior.position.toLowerCase().includes(query) &&
        !senior.skills.some(skill => skill.toLowerCase().includes(query))
      ) {
        return false;
      }
    }
    
    // Filter by department
    if (selectedDepartment !== "All Departments") {
      if (!senior.batch.includes(selectedDepartment)) {
        return false;
      }
    }
    
    // Filter by year
    if (selectedYear !== "All Years") {
      if (!senior.batch.includes(selectedYear)) {
        return false;
      }
    }
    
    return true;
  });
  
  return (
    <AppShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">Connect with Alumni</h1>
          <p className="text-neutral-600">Connect with graduates for mentorship and career guidance</p>
        </div>
        
        <div className="bg-white shadow-sm rounded-lg p-6">
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-neutral-400" />
              </div>
              <Input
                type="text"
                placeholder="Search by name, position, or skills..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div className="w-full sm:w-48">
              <Select value={selectedDepartment} onValueChange={setSelectedDepartment}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Department" />
                </SelectTrigger>
                <SelectContent>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="w-full sm:w-48">
              <Select value={selectedYear} onValueChange={setSelectedYear}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Batch Year" />
                </SelectTrigger>
                <SelectContent>
                  {batchYears.map((year) => (
                    <SelectItem key={year} value={year}>
                      {year}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Tabs defaultValue="alumni" className="w-full">
            <TabsList className="mb-6">
              <TabsTrigger value="alumni">Alumni</TabsTrigger>
              <TabsTrigger value="faculty">Faculty</TabsTrigger>
              <TabsTrigger value="industry">Industry Experts</TabsTrigger>
            </TabsList>
            
            <TabsContent value="alumni" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredSeniors.length > 0 ? (
                  filteredSeniors.map((senior) => (
                    <Card key={senior.id} className="hover:shadow-md transition-shadow duration-200">
                      <CardContent className="p-6">
                        <div className="flex flex-col sm:flex-row gap-4">
                          <div className="flex-shrink-0 flex flex-col items-center">
                            <Avatar className="h-20 w-20">
                              <AvatarImage src={senior.avatar} alt={senior.name} />
                              <AvatarFallback className="bg-primary/10 text-primary text-xl">
                                {getInitials(senior.name)}
                              </AvatarFallback>
                            </Avatar>
                            <Button 
                              variant="outline" 
                              size="sm" 
                              className="mt-2 w-full text-primary hover:bg-primary/10 border-primary"
                            >
                              <Mail className="h-4 w-4 mr-2" />
                              Connect
                            </Button>
                          </div>
                          
                          <div className="flex-1">
                            <h3 className="text-lg font-semibold text-neutral-900">{senior.name}</h3>
                            <div className="flex items-center text-sm text-neutral-600 mt-1">
                              <Briefcase className="h-4 w-4 text-neutral-400 mr-1" />
                              {senior.position}
                            </div>
                            <div className="flex items-center text-sm text-neutral-600 mt-1">
                              <School className="h-4 w-4 text-neutral-400 mr-1" />
                              {senior.batch}
                            </div>
                            <div className="flex items-center text-sm text-neutral-600 mt-1">
                              <MapPin className="h-4 w-4 text-neutral-400 mr-1" />
                              {senior.location}
                            </div>
                            
                            <p className="text-sm text-neutral-600 mt-3">
                              {senior.bio}
                            </p>
                            
                            <div className="mt-3 flex flex-wrap gap-2">
                              {senior.skills.map((skill, idx) => (
                                <Badge key={idx} variant="outline" className="bg-primary/5">
                                  {skill}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <div className="col-span-2 text-center py-8">
                    <p className="text-neutral-500">No alumni found matching your criteria.</p>
                    <p className="text-neutral-400 mt-2">
                      Try adjusting your search or filters.
                    </p>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="faculty">
              <div className="text-center py-8">
                <p className="text-neutral-500">Faculty profiles will be available soon.</p>
              </div>
            </TabsContent>
            
            <TabsContent value="industry">
              <div className="text-center py-8">
                <p className="text-neutral-500">Industry expert profiles will be available soon.</p>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </AppShell>
  );
}
