import { useState } from "react";
import { AppShell } from "@/components/layout/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { MapPin, Building, School, BookOpen, Coffee, Home, Utensils, Dumbbell } from "lucide-react";

type BuildingCategory = "academic" | "administrative" | "recreational" | "residential" | "all";

interface Building {
  id: number;
  name: string;
  description: string;
  category: string;
  location: string;
  facilities: string[];
  icon: React.ReactNode;
}

export default function CampusMapPage() {
  const [selectedCategory, setSelectedCategory] = useState<BuildingCategory>("all");
  const [selectedBuilding, setSelectedBuilding] = useState<Building | null>(null);
  
  // Campus buildings data
  const buildings: Building[] = [
    {
      id: 1,
      name: "Computer Science Block",
      description: "Houses the Department of Computer Science and Engineering with state-of-the-art labs and classrooms.",
      category: "academic",
      location: "North Campus",
      facilities: ["Computer Labs", "Lecture Halls", "Faculty Offices", "Student Lounge", "High-Speed Wi-Fi"],
      icon: <School className="h-12 w-12 text-primary" />
    },
    {
      id: 2,
      name: "Engineering Block",
      description: "Home to various engineering departments including Mechanical, Electrical, and Civil Engineering.",
      category: "academic",
      location: "North Campus",
      facilities: ["Engineering Labs", "Workshop", "Lecture Halls", "Conference Room"],
      icon: <Building className="h-12 w-12 text-primary" />
    },
    {
      id: 3,
      name: "Central Library",
      description: "The main library with extensive collection of books, journals, and digital resources.",
      category: "academic",
      location: "Central Campus",
      facilities: ["Reading Rooms", "Digital Library", "Group Study Spaces", "Quiet Zones", "Wi-Fi"],
      icon: <BookOpen className="h-12 w-12 text-primary" />
    },
    {
      id: 4,
      name: "Student Center",
      description: "The hub of student activities and organizations with meeting spaces and recreational areas.",
      category: "recreational",
      location: "Central Campus",
      facilities: ["Meeting Rooms", "Auditorium", "Cafeteria", "Student Club Offices"],
      icon: <Coffee className="h-12 w-12 text-secondary" />
    },
    {
      id: 5,
      name: "Boys Hostel",
      description: "Residential facility for male students with modern amenities and security.",
      category: "residential",
      location: "East Campus",
      facilities: ["Single/Double Rooms", "Common Room", "Dining Hall", "Laundry", "Wi-Fi"],
      icon: <Home className="h-12 w-12 text-accent" />
    },
    {
      id: 6,
      name: "Girls Hostel",
      description: "Residential facility for female students with modern amenities and security.",
      category: "residential",
      location: "East Campus",
      facilities: ["Single/Double Rooms", "Common Room", "Dining Hall", "Laundry", "Wi-Fi"],
      icon: <Home className="h-12 w-12 text-accent" />
    },
    {
      id: 7,
      name: "Sports Complex",
      description: "Comprehensive sports facility with indoor and outdoor sports areas.",
      category: "recreational",
      location: "West Campus",
      facilities: ["Gymnasium", "Swimming Pool", "Basketball Court", "Cricket Field", "Tennis Courts"],
      icon: <Dumbbell className="h-12 w-12 text-secondary" />
    },
    {
      id: 8,
      name: "Administrative Block",
      description: "Houses the administrative offices including registrar, admissions, and accounts.",
      category: "administrative",
      location: "Central Campus",
      facilities: ["Main Office", "Conference Room", "Admission Cell", "Finance Department"],
      icon: <Building className="h-12 w-12 text-neutral-600" />
    },
    {
      id: 9,
      name: "Cafeteria",
      description: "Main dining facility offering a variety of food options for students and staff.",
      category: "recreational",
      location: "Central Campus",
      facilities: ["Dining Area", "Food Counters", "Outdoor Seating", "Wi-Fi"],
      icon: <Utensils className="h-12 w-12 text-secondary" />
    }
  ];
  
  // Filter buildings based on selected category
  const filteredBuildings = selectedCategory === "all" 
    ? buildings 
    : buildings.filter(building => building.category === selectedCategory);
  
  // Handle building selection
  const handleBuildingSelect = (building: Building) => {
    setSelectedBuilding(building);
  };
  
  return (
    <AppShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">Campus Map</h1>
          <p className="text-neutral-600">Explore campus buildings, facilities, and locations</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className="h-full">
              <CardHeader>
                <CardTitle>Interactive Campus Map</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-neutral-100 h-[400px] rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="h-12 w-12 text-neutral-300 mx-auto mb-3" />
                    <p className="text-neutral-500">Interactive Campus Map</p>
                    <p className="text-sm text-neutral-400 mt-2">A visual representation of the campus layout will be available soon</p>
                  </div>
                </div>
                
                {selectedBuilding && (
                  <div className="mt-4 p-4 border border-neutral-200 rounded-lg bg-neutral-50">
                    <div className="flex items-start">
                      <div className="mr-4">
                        {selectedBuilding.icon}
                      </div>
                      <div>
                        <h3 className="text-lg font-medium text-neutral-900">{selectedBuilding.name}</h3>
                        <p className="text-neutral-600 mt-1">{selectedBuilding.description}</p>
                        <div className="flex items-center mt-2 text-sm text-neutral-500">
                          <MapPin className="h-4 w-4 mr-1" />
                          {selectedBuilding.location}
                        </div>
                        <div className="mt-3">
                          <h4 className="text-sm font-medium text-neutral-700">Facilities:</h4>
                          <ul className="mt-1 grid grid-cols-2 gap-x-4 gap-y-1">
                            {selectedBuilding.facilities.map((facility, index) => (
                              <li key={index} className="text-sm text-neutral-600 flex items-center">
                                <div className="h-1.5 w-1.5 rounded-full bg-primary mr-2"></div>
                                {facility}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          
          <div>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Campus Buildings</CardTitle>
                <Select value={selectedCategory} onValueChange={(value) => setSelectedCategory(value as BuildingCategory)}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Buildings</SelectItem>
                    <SelectItem value="academic">Academic</SelectItem>
                    <SelectItem value="administrative">Administrative</SelectItem>
                    <SelectItem value="recreational">Recreational</SelectItem>
                    <SelectItem value="residential">Residential</SelectItem>
                  </SelectContent>
                </Select>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-[480px] overflow-y-auto pr-2">
                  {filteredBuildings.map((building) => (
                    <div 
                      key={building.id} 
                      className={`p-3 border rounded-lg cursor-pointer transition-all hover:border-primary ${
                        selectedBuilding?.id === building.id ? 'border-primary bg-primary/5' : 'border-neutral-200'
                      }`}
                      onClick={() => handleBuildingSelect(building)}
                    >
                      <div className="flex items-center">
                        <div className="mr-3">
                          {building.icon}
                        </div>
                        <div>
                          <h3 className="font-medium text-neutral-900">{building.name}</h3>
                          <div className="flex items-center text-xs text-neutral-500 mt-1">
                            <MapPin className="h-3 w-3 mr-1" />
                            {building.location}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Campus Facilities</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="buildings" className="w-full">
              <TabsList className="mb-6">
                <TabsTrigger value="buildings">Buildings Directory</TabsTrigger>
                <TabsTrigger value="facilities">Facilities</TabsTrigger>
                <TabsTrigger value="hours">Operating Hours</TabsTrigger>
              </TabsList>
              
              <TabsContent value="buildings">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Building</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Location</TableHead>
                        <TableHead>Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {buildings.map((building) => (
                        <TableRow key={building.id}>
                          <TableCell className="font-medium">{building.name}</TableCell>
                          <TableCell className="capitalize">{building.category}</TableCell>
                          <TableCell>{building.location}</TableCell>
                          <TableCell>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => handleBuildingSelect(building)}
                            >
                              View Details
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
              
              <TabsContent value="facilities">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  <div className="border border-neutral-200 rounded-lg p-4">
                    <div className="flex items-center mb-3">
                      <BookOpen className="h-6 w-6 text-primary mr-2" />
                      <h3 className="font-medium">Academic Facilities</h3>
                    </div>
                    <ul className="space-y-2 text-sm text-neutral-600">
                      <li>Libraries and Reading Rooms</li>
                      <li>Computer Labs</li>
                      <li>Lecture Halls</li>
                      <li>Science and Engineering Labs</li>
                      <li>Research Centers</li>
                    </ul>
                  </div>
                  
                  <div className="border border-neutral-200 rounded-lg p-4">
                    <div className="flex items-center mb-3">
                      <Dumbbell className="h-6 w-6 text-secondary mr-2" />
                      <h3 className="font-medium">Sports & Recreation</h3>
                    </div>
                    <ul className="space-y-2 text-sm text-neutral-600">
                      <li>Gymnasium</li>
                      <li>Swimming Pool</li>
                      <li>Sports Fields</li>
                      <li>Indoor Courts</li>
                      <li>Student Activity Center</li>
                    </ul>
                  </div>
                  
                  <div className="border border-neutral-200 rounded-lg p-4">
                    <div className="flex items-center mb-3">
                      <Utensils className="h-6 w-6 text-secondary mr-2" />
                      <h3 className="font-medium">Dining Facilities</h3>
                    </div>
                    <ul className="space-y-2 text-sm text-neutral-600">
                      <li>Main Cafeteria</li>
                      <li>Coffee Shops</li>
                      <li>Food Courts</li>
                      <li>Canteens</li>
                      <li>Vending Machine Locations</li>
                    </ul>
                  </div>
                  
                  <div className="border border-neutral-200 rounded-lg p-4">
                    <div className="flex items-center mb-3">
                      <Home className="h-6 w-6 text-accent mr-2" />
                      <h3 className="font-medium">Residential Facilities</h3>
                    </div>
                    <ul className="space-y-2 text-sm text-neutral-600">
                      <li>Student Hostels</li>
                      <li>Faculty Housing</li>
                      <li>Guest Accommodations</li>
                      <li>Laundry Services</li>
                      <li>Common Areas and Lounges</li>
                    </ul>
                  </div>
                  
                  <div className="border border-neutral-200 rounded-lg p-4">
                    <div className="flex items-center mb-3">
                      <Building className="h-6 w-6 text-neutral-600 mr-2" />
                      <h3 className="font-medium">Administrative Facilities</h3>
                    </div>
                    <ul className="space-y-2 text-sm text-neutral-600">
                      <li>Administration Block</li>
                      <li>Registrar's Office</li>
                      <li>Finance Department</li>
                      <li>Examination Wing</li>
                      <li>Student Affairs Office</li>
                    </ul>
                  </div>
                  
                  <div className="border border-neutral-200 rounded-lg p-4">
                    <div className="flex items-center mb-3">
                      <Coffee className="h-6 w-6 text-secondary mr-2" />
                      <h3 className="font-medium">Other Amenities</h3>
                    </div>
                    <ul className="space-y-2 text-sm text-neutral-600">
                      <li>Medical Center</li>
                      <li>Bank and ATMs</li>
                      <li>Post Office</li>
                      <li>Campus Store</li>
                      <li>Transport Facilities</li>
                    </ul>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="hours">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Facility</TableHead>
                        <TableHead>Weekday Hours</TableHead>
                        <TableHead>Weekend Hours</TableHead>
                        <TableHead>Holiday Hours</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell className="font-medium">Central Library</TableCell>
                        <TableCell>8:00 AM - 10:00 PM</TableCell>
                        <TableCell>9:00 AM - 6:00 PM</TableCell>
                        <TableCell>Closed</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Computer Labs</TableCell>
                        <TableCell>9:00 AM - 8:00 PM</TableCell>
                        <TableCell>10:00 AM - 5:00 PM</TableCell>
                        <TableCell>Closed</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Sports Complex</TableCell>
                        <TableCell>6:00 AM - 9:00 PM</TableCell>
                        <TableCell>7:00 AM - 8:00 PM</TableCell>
                        <TableCell>8:00 AM - 6:00 PM</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Main Cafeteria</TableCell>
                        <TableCell>7:30 AM - 10:00 PM</TableCell>
                        <TableCell>8:00 AM - 9:00 PM</TableCell>
                        <TableCell>9:00 AM - 7:00 PM</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Administrative Offices</TableCell>
                        <TableCell>9:00 AM - 5:00 PM</TableCell>
                        <TableCell>Closed</TableCell>
                        <TableCell>Closed</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Student Center</TableCell>
                        <TableCell>8:00 AM - 9:00 PM</TableCell>
                        <TableCell>10:00 AM - 6:00 PM</TableCell>
                        <TableCell>Closed</TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Medical Center</TableCell>
                        <TableCell>8:00 AM - 8:00 PM</TableCell>
                        <TableCell>9:00 AM - 5:00 PM</TableCell>
                        <TableCell>9:00 AM - 1:00 PM</TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
                <p className="text-sm text-neutral-500 mt-4">
                  Note: Operating hours may change during examination periods, special events, or emergencies.
                  Please check the official notices for any changes to the regular schedule.
                </p>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}
