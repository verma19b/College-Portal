import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BookOpenCheck, Users } from "lucide-react";

const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Invalid email address"),
  role: z.enum(["student", "faculty", "alumni"], {
    required_error: "Please select a role",
  }),
  batch: z.string().min(1, "Batch is required"),
  studentId: z.string().optional(),
});

type LoginFormData = z.infer<typeof loginSchema>;
type RegisterFormData = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();
  const [, navigate] = useLocation();
  const [selectedRole, setSelectedRole] = useState<string>("student");

  // Redirect if user is already logged in
  useEffect(() => {
    if (user) {
      navigate("/");
    }
  }, [user, navigate]);

  // Login form
  const loginForm = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  // Register form
  const registerForm = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      firstName: "",
      lastName: "",
      email: "",
      role: "student", // Default role is student
      batch: "",
      studentId: "",
    },
  });

  // Submit handlers
  const onLoginSubmit = (data: LoginFormData) => {
    loginMutation.mutate(data);
  };

  const onRegisterSubmit = (data: RegisterFormData) => {
    registerMutation.mutate(data);
  };

  // Generate batch options: Last 4 years from current year
  const currentYear = new Date().getFullYear();
  const batchYears = Array.from({ length: 4 }, (_, i) => currentYear - i);

  // Departments
  const departments = ["CSE", "ECE", "ME", "CE", "EE", "IT", "BT", "CH"];

  return (
    <div className="min-h-screen flex flex-col md:flex-row relative">
      {/* Hero section */}
      <div className="bg-slate-50 md:w-1/2 flex flex-col items-center justify-center p-8 md:p-12 relative overflow-hidden">

        <div className="max-w-md text-center md:text-left relative z-10">
          <div className="mb-8 flex items-center justify-center md:justify-start">
            <div className="h-14 w-14 rounded-xl bg-gradient-to-br from-primary to-primary-dark flex items-center justify-center text-white font-bold text-2xl shadow-lg">
              CC
            </div>
            <h1 className="ml-4 text-3xl font-extrabold text-primary">
              Campus Connect
            </h1>
          </div>

          <h2 className="text-4xl font-extrabold text-neutral-900 mb-6 leading-tight">
            Connect, Share, and Excel in Your Campus Journey
          </h2>
          <p className="text-lg text-neutral-600 mb-10 leading-relaxed">
            Join the platform where students collaborate, share resources, and stay updated with everything happening on campus.
          </p>

          <div className="space-y-8">
            <div className="flex items-start bg-white/60 backdrop-blur-sm rounded-xl p-5 shadow-sm hover:shadow-md transition-all">
              <div className="flex-shrink-0 mt-1">
                <div className="p-3 rounded-lg bg-primary/10 text-primary">
                  <BookOpenCheck className="h-7 w-7" />
                </div>
              </div>
              <div className="ml-5">
                <h3 className="text-xl font-semibold text-neutral-900">Academic Excellence</h3>
                <p className="mt-2 text-neutral-600 leading-relaxed">
                  Access study materials, track attendance, and monitor your academic progress all in one place.
                </p>
              </div>
            </div>

            <div className="flex items-start bg-white/60 backdrop-blur-sm rounded-xl p-5 shadow-sm hover:shadow-md transition-all">
              <div className="flex-shrink-0 mt-1">
                <div className="p-3 rounded-lg bg-primary/10 text-primary">
                  <Users className="h-7 w-7" />
                </div>
              </div>
              <div className="ml-5">
                <h3 className="text-xl font-semibold text-neutral-900">Community & Networking</h3>
                <p className="mt-2 text-neutral-600 leading-relaxed">
                  Connect with seniors, participate in forums, and build valuable relationships within your college community.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Auth forms */}
      <div className="flex-1 flex items-center justify-center p-8 bg-gradient-to-b from-white to-gray-50">
        <div className="w-full max-w-md">
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-8 p-1 bg-gray-100/80 rounded-xl">
              <TabsTrigger value="login" className="rounded-lg text-base py-2.5">Login</TabsTrigger>
              <TabsTrigger value="register" className="rounded-lg text-base py-2.5">Register</TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <Card className="border-none shadow-lg">
                <CardHeader className="pb-4">
                  <CardTitle className="text-2xl font-bold text-primary">Welcome back!</CardTitle>
                  <CardDescription className="text-base">Login to your Campus Connect account</CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...loginForm}>
                    <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-5">
                      <FormField
                        control={loginForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-medium text-gray-700">Username</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="username" 
                                className="h-11 px-4 rounded-lg border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary transition-all" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={loginForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-medium text-gray-700">Password</FormLabel>
                            <FormControl>
                              <Input 
                                type="password" 
                                placeholder="••••••••" 
                                className="h-11 px-4 rounded-lg border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary transition-all" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button 
                        type="submit" 
                        className="w-full h-11 text-base font-medium shadow-md hover:shadow-lg transition-all bg-gradient-to-r from-primary to-primary-dark hover:opacity-90" 
                        disabled={loginMutation.isPending}
                      >
                        {loginMutation.isPending ? (
                          <span className="flex items-center justify-center gap-2">
                            <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Logging in...
                          </span>
                        ) : "Login to Campus Connect"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="register">
              <Card className="border-none shadow-lg">
                <CardHeader className="pb-4">
                  <CardTitle className="text-2xl font-bold text-primary">Create an account</CardTitle>
                  <CardDescription className="text-base">Join Campus Connect to get started</CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...registerForm}>
                    <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-5">
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={registerForm.control}
                          name="firstName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-sm font-medium text-gray-700">First Name</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="John" 
                                  className="h-11 px-4 rounded-lg border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary transition-all" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={registerForm.control}
                          name="lastName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-sm font-medium text-gray-700">Last Name</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Doe" 
                                  className="h-11 px-4 rounded-lg border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary transition-all" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={registerForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-medium text-gray-700">Email</FormLabel>
                            <FormControl>
                              <Input 
                                type="email" 
                                placeholder="john.doe@example.com" 
                                className="h-11 px-4 rounded-lg border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary transition-all" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={registerForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-medium text-gray-700">Username</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="johndoe" 
                                className="h-11 px-4 rounded-lg border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary transition-all" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={registerForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-medium text-gray-700">Password</FormLabel>
                            <FormControl>
                              <Input 
                                type="password" 
                                placeholder="••••••••" 
                                className="h-11 px-4 rounded-lg border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary transition-all" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={registerForm.control}
                        name="role"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm font-medium text-gray-700">I am a</FormLabel>
                            <Select 
                              onValueChange={(value) => {
                                field.onChange(value);
                                setSelectedRole(value);
                              }} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger className="h-11 px-4 rounded-lg border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary transition-all">
                                  <SelectValue placeholder="Select your role" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="student">Student</SelectItem>
                                <SelectItem value="faculty">Faculty</SelectItem>
                                <SelectItem value="alumni">Alumni</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Show batch field for students and alumni only */}
                      {selectedRole !== "faculty" && (
                        <FormField
                          control={registerForm.control}
                          name="batch"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-sm font-medium text-gray-700">
                                {selectedRole === "student" ? "Batch" : "Graduation Batch"}
                              </FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger className="h-11 px-4 rounded-lg border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary transition-all">
                                    <SelectValue placeholder={
                                      selectedRole === "student" ? "Select your batch" : "Select your graduation batch"
                                    } />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {batchYears.map(year => (
                                    departments.map(dept => (
                                      <SelectItem key={`${year} ${dept}`} value={`${year} ${dept}`}>
                                        {year} {dept}
                                      </SelectItem>
                                    ))
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}

                      {/* Show department field for faculty only */}
                      {selectedRole === "faculty" && (
                        <FormField
                          control={registerForm.control}
                          name="batch"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-sm font-medium text-gray-700">Department</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger className="h-11 px-4 rounded-lg border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary transition-all">
                                    <SelectValue placeholder="Select your department" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {departments.map(dept => (
                                    <SelectItem key={dept} value={dept}>
                                      {dept}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}

                      {/* Show Student ID field only for students */}
                      {selectedRole === "student" && (
                        <FormField
                          control={registerForm.control}
                          name="studentId"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-sm font-medium text-gray-700">Student ID (Optional)</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="2023CS0042" 
                                  className="h-11 px-4 rounded-lg border-gray-200 focus:border-primary focus:ring-1 focus:ring-primary transition-all" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      )}

                      <Button 
                        type="submit" 
                        className="w-full h-11 text-base font-medium shadow-md hover:shadow-lg transition-all bg-gradient-to-r from-primary to-primary-dark hover:opacity-90" 
                        disabled={registerMutation.isPending}
                      >
                        {registerMutation.isPending ? (
                          <span className="flex items-center justify-center gap-2">
                            <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Creating account...
                          </span>
                        ) : "Join Campus Connect"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      {/* Copyright footer */}
      <div className="absolute bottom-0 left-0 right-0 py-3 px-6 text-center bg-white/80 backdrop-blur-sm border-t">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="text-sm text-gray-500">
            © {new Date().getFullYear()} Campus Connect. All rights reserved.
          </div>
          <div className="text-sm font-medium text-primary">
            Developed by Bharat Verma
          </div>
        </div>
      </div>
    </div>
  );
}