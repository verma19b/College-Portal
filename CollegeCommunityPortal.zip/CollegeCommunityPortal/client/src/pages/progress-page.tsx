import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/layout/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { BadgeCheck, LineChart, TrendingUp, TrendingDown } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Semester options
const semesters = [
  "Current Semester",
  "Winter 2023",
  "Summer 2023",
  "Spring 2023",
  "Winter 2022",
  "All Semesters"
];

export default function ProgressPage() {
  const [selectedSemester, setSelectedSemester] = useState<string>("Current Semester");
  
  // Fetch academic progress data
  const { data: progressData, isLoading } = useQuery({
    queryKey: [
      "/api/academic-progress", 
      selectedSemester !== "All Semesters" && selectedSemester !== "Current Semester" 
        ? { semester: selectedSemester } 
        : undefined
    ],
    // Using default query function
  });
  
  // Calculate academic statistics
  const calculateAcademicStats = () => {
    if (!progressData || progressData.length === 0) {
      return {
        averagePercentage: 0,
        coursesPassed: 0,
        coursesTotal: 0,
        topGrade: null,
        lowestGrade: null
      };
    }
    
    const totalPercentage = progressData.reduce((sum: number, course: any) => sum + (course.percentage || 0), 0);
    const averagePercentage = Math.round(totalPercentage / progressData.length);
    
    const coursesPassed = progressData.filter((course: any) => {
      // Consider grades A, B, C, D as passing (adjust based on your grading system)
      return course.grade && ['A+', 'A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D'].includes(course.grade);
    }).length;
    
    // Sort courses by percentage to find top and lowest grades
    const sortedCourses = [...progressData].sort((a: any, b: any) => 
      (b.percentage || 0) - (a.percentage || 0)
    );
    
    return {
      averagePercentage,
      coursesPassed,
      coursesTotal: progressData.length,
      topGrade: sortedCourses[0],
      lowestGrade: sortedCourses[sortedCourses.length - 1]
    };
  };
  
  const stats = calculateAcademicStats();
  
  // Helper function to get color based on grade
  const getGradeColor = (grade: string) => {
    if (!grade) return "text-neutral-500";
    
    if (['A+', 'A', 'A-'].includes(grade)) return "text-green-600";
    if (['B+', 'B', 'B-'].includes(grade)) return "text-blue-600";
    if (['C+', 'C', 'C-'].includes(grade)) return "text-amber-600";
    if (['D'].includes(grade)) return "text-orange-600";
    return "text-red-600";
  };
  
  // Helper function to get progress bar color
  const getProgressColor = (percentage: number) => {
    if (percentage >= 85) return "bg-green-500";
    if (percentage >= 70) return "bg-blue-500";
    if (percentage >= 55) return "bg-amber-500";
    if (percentage >= 40) return "bg-orange-500";
    return "bg-red-500";
  };
  
  return (
    <AppShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">Academic Progress</h1>
          <p className="text-neutral-600">Track your academic performance and course grades</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Average Performance Card */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-medium">Overall Performance</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-20 w-full" />
              ) : (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-semibold text-2xl">{stats.averagePercentage}%</div>
                    <div className="flex items-center text-sm text-green-600">
                      <TrendingUp className="h-4 w-4 mr-1" />
                      <span>+5.2% from last semester</span>
                    </div>
                  </div>
                  <Progress value={stats.averagePercentage} className={getProgressColor(stats.averagePercentage)} />
                  
                  <div className="mt-4 flex justify-between items-center">
                    <div className="text-sm text-neutral-600">Course Completion:</div>
                    <div className="font-medium">
                      {stats.coursesPassed} / {stats.coursesTotal} courses
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Top Performance Card */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-medium">Top Performance</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-20 w-full" />
              ) : stats.topGrade ? (
                <div className="flex items-start">
                  <BadgeCheck className="h-10 w-10 text-green-500 mr-3 flex-shrink-0" />
                  <div>
                    <div className="font-medium">{stats.topGrade.subject}</div>
                    <div className="text-sm text-neutral-600">{stats.topGrade.semester}</div>
                    <div className="mt-2 flex items-center">
                      <div className={`text-lg font-semibold ${getGradeColor(stats.topGrade.grade)}`}>
                        {stats.topGrade.grade}
                      </div>
                      <div className="ml-2 text-sm text-neutral-600">
                        ({stats.topGrade.percentage}%)
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-20 text-neutral-500">
                  No grade data available
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Areas for Improvement Card */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-medium">Areas for Improvement</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-20 w-full" />
              ) : stats.lowestGrade ? (
                <div className="flex items-start">
                  <TrendingDown className="h-10 w-10 text-amber-500 mr-3 flex-shrink-0" />
                  <div>
                    <div className="font-medium">{stats.lowestGrade.subject}</div>
                    <div className="text-sm text-neutral-600">{stats.lowestGrade.semester}</div>
                    <div className="mt-2 flex items-center">
                      <div className={`text-lg font-semibold ${getGradeColor(stats.lowestGrade.grade)}`}>
                        {stats.lowestGrade.grade}
                      </div>
                      <div className="ml-2 text-sm text-neutral-600">
                        ({stats.lowestGrade.percentage}%)
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-20 text-neutral-500">
                  No grade data available
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <CardTitle>Academic Records</CardTitle>
              <Select value={selectedSemester} onValueChange={setSelectedSemester}>
                <SelectTrigger className="w-full sm:w-[200px]">
                  <SelectValue placeholder="Semester" />
                </SelectTrigger>
                <SelectContent>
                  {semesters.map((semester) => (
                    <SelectItem key={semester} value={semester}>
                      {semester}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="courses" className="w-full">
              <TabsList className="mb-6">
                <TabsTrigger value="courses">Courses</TabsTrigger>
                <TabsTrigger value="trends">Performance Trends</TabsTrigger>
              </TabsList>
              
              <TabsContent value="courses">
                {isLoading ? (
                  <Skeleton className="h-64 w-full" />
                ) : progressData && progressData.length > 0 ? (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Subject</TableHead>
                          <TableHead>Semester</TableHead>
                          <TableHead>Grade</TableHead>
                          <TableHead>Percentage</TableHead>
                          <TableHead>Notes</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {progressData.map((record: any) => (
                          <TableRow key={record.id}>
                            <TableCell className="font-medium">{record.subject}</TableCell>
                            <TableCell>{record.semester}</TableCell>
                            <TableCell className={getGradeColor(record.grade)}>
                              <span className="font-medium">{record.grade}</span>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <span>{record.percentage}%</span>
                                <Progress 
                                  value={record.percentage} 
                                  className={`w-20 h-2 ${getProgressColor(record.percentage)}`} 
                                />
                              </div>
                            </TableCell>
                            <TableCell className="text-sm text-neutral-600">
                              {record.notes || "-"}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <LineChart className="h-12 w-12 text-neutral-300 mx-auto mb-3" />
                    <p className="text-neutral-500">No academic records found for the selected semester.</p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="trends">
                <div className="text-center py-8">
                  <LineChart className="h-12 w-12 text-neutral-300 mx-auto mb-3" />
                  <p className="text-neutral-500">Performance trend analysis will be available soon.</p>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}
