import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { EventCard } from "@/components/events/event-card";
import { AppShell } from "@/components/layout/app-shell";
import { Calendar as CalendarIcon, Search, Plus, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

// Event categories for filtering
const categories = [
  "All",
  "Workshop",
  "Seminar",
  "Cultural",
  "Tech Fest",
  "Talk",
  "Orientation",
  "Club",
  "Other"
];

export default function EventsPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [date, setDate] = useState<Date | undefined>(undefined);
  
  // Fetch events
  const { data: events, isLoading } = useQuery({
    queryKey: [
      "/api/events", 
      { upcoming: true },
      selectedCategory !== "All" ? { category: selectedCategory } : undefined
    ],
    // Using default query function
  });
  
  // Filter events by search query and selected date
  const filteredEvents = events?.filter((event: any) => {
    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      if (
        !event.title.toLowerCase().includes(query) &&
        !event.description.toLowerCase().includes(query) &&
        !event.location.toLowerCase().includes(query) &&
        !event.organizer.toLowerCase().includes(query)
      ) {
        return false;
      }
    }
    
    // Filter by selected date
    if (date) {
      const eventDate = new Date(event.date);
      if (
        eventDate.getDate() !== date.getDate() ||
        eventDate.getMonth() !== date.getMonth() ||
        eventDate.getFullYear() !== date.getFullYear()
      ) {
        return false;
      }
    }
    
    return true;
  });
  
  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">Events Calendar</h1>
            <p className="text-neutral-600">Stay updated with college events and activities</p>
          </div>
          
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Create Event
          </Button>
        </div>
        
        <div className="bg-white shadow-sm rounded-lg p-6">
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-neutral-400" />
              </div>
              <Input
                type="text"
                placeholder="Search events..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full sm:w-auto justify-start text-left font-normal">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, "PPP") : "Pick a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
            
            <div className="w-full sm:w-48">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Event Type" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            {(date || selectedCategory !== "All" || searchQuery) && (
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => {
                  setDate(undefined);
                  setSelectedCategory("All");
                  setSearchQuery("");
                }}
                className="sm:self-center"
              >
                <Filter className="h-4 w-4" />
              </Button>
            )}
          </div>
          
          <div className="space-y-6">
            {isLoading ? (
              Array(3).fill(0).map((_, i) => (
                <div key={i} className="mb-4">
                  <Skeleton className="h-[200px] w-full rounded-lg" />
                </div>
              ))
            ) : filteredEvents && filteredEvents.length > 0 ? (
              filteredEvents.map((event: any) => (
                <EventCard key={event.id} event={event} />
              ))
            ) : (
              <div className="text-center py-8">
                <p className="text-neutral-500">No events found.</p>
                {(searchQuery || selectedCategory !== "All" || date) && (
                  <p className="text-neutral-400 mt-2">
                    Try adjusting your filters.
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
