import { Header } from "@/components/layout/header";
import { Sidebar } from "@/components/layout/sidebar";
import { MobileNav } from "@/components/layout/mobile-nav";
import { WelcomeSection } from "@/components/dashboard/welcome-section";
import { QuickStats } from "@/components/dashboard/quick-stats";
import { RecentActivity } from "@/components/dashboard/recent-activity";
import { ForumTopics } from "@/components/dashboard/forum-topics";
import { UpcomingEvents } from "@/components/dashboard/upcoming-events";
import { SeniorConnect } from "@/components/dashboard/senior-connect";
import { BusTracker } from "@/components/dashboard/bus-tracker";

export default function DashboardPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <div className="flex-1 flex overflow-hidden">
        <Sidebar />
        
        <main className="flex-1 overflow-y-auto bg-neutral-100 pb-16 md:pb-0">
          <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
            <div className="space-y-6">
              {/* Welcome section */}
              <WelcomeSection />
              
              {/* Quick stats */}
              <QuickStats />
              
              {/* Two column layout */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Activity & Forum feed */}
                <div className="lg:col-span-2 space-y-6">
                  <RecentActivity />
                  <ForumTopics />
                </div>
                
                {/* Events, Connect & Bus tracker */}
                <div className="space-y-6">
                  <UpcomingEvents />
                  <SeniorConnect />
                  <BusTracker />
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
      
      <MobileNav />
    </div>
  );
}
