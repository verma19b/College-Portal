import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/layout/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { CalendarCheck, AlertCircle, CheckCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useState } from "react";

// Subject options
const subjects = [
  "All Subjects",
  "Data Structures",
  "Algorithms",
  "Database Systems",
  "Web Development",
  "Computer Networks",
  "Operating Systems",
  "Software Engineering"
];

export default function AttendancePage() {
  const [selectedSubject, setSelectedSubject] = useState<string>("All Subjects");
  
  // Fetch attendance data
  const { data: attendanceData, isLoading } = useQuery({
    queryKey: [
      "/api/attendance", 
      selectedSubject !== "All Subjects" ? { subject: selectedSubject } : undefined
    ],
    // Using default query function
  });
  
  // Calculate attendance statistics
  const calculateAttendanceStats = () => {
    if (!attendanceData || attendanceData.length === 0) {
      return {
        total: 0,
        present: 0,
        absent: 0,
        excused: 0,
        percentage: 0
      };
    }
    
    const total = attendanceData.length;
    const present = attendanceData.filter((record: any) => record.status === "present").length;
    const absent = attendanceData.filter((record: any) => record.status === "absent").length;
    const excused = attendanceData.filter((record: any) => record.status === "excused").length;
    
    // Calculate percentage excluding excused absences
    const attendancePercentage = Math.round((present / (present + absent)) * 100);
    
    return {
      total,
      present,
      absent,
      excused,
      percentage: attendancePercentage
    };
  };
  
  const stats = calculateAttendanceStats();
  
  // Helper function to get badge color based on attendance status
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "present":
        return <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">Present</Badge>;
      case "absent":
        return <Badge variant="outline" className="bg-red-50 text-red-600 border-red-200">Absent</Badge>;
      case "excused":
        return <Badge variant="outline" className="bg-amber-50 text-amber-600 border-amber-200">Excused</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  // Helper function to get status color for progress bar
  const getProgressColor = (percentage: number) => {
    if (percentage >= 85) return "bg-green-500";
    if (percentage >= 75) return "bg-amber-500";
    return "bg-red-500";
  };
  
  return (
    <AppShell>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-neutral-900">Attendance Tracker</h1>
          <p className="text-neutral-600">Monitor your class attendance and maintain good academic standing</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Overall Attendance Card */}
          <Card className="col-span-1 md:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-medium">Overall Attendance</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-20 w-full" />
              ) : (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-semibold">{stats.percentage}%</div>
                    <div className="text-sm text-neutral-500">
                      {stats.present} / {stats.present + stats.absent} classes
                    </div>
                  </div>
                  <Progress value={stats.percentage} className={getProgressColor(stats.percentage)} />
                  
                  <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                    <div className="bg-green-50 rounded-md p-2">
                      <div className="text-green-600 font-medium">{stats.present}</div>
                      <div className="text-xs text-neutral-600">Present</div>
                    </div>
                    <div className="bg-red-50 rounded-md p-2">
                      <div className="text-red-600 font-medium">{stats.absent}</div>
                      <div className="text-xs text-neutral-600">Absent</div>
                    </div>
                    <div className="bg-amber-50 rounded-md p-2">
                      <div className="text-amber-600 font-medium">{stats.excused}</div>
                      <div className="text-xs text-neutral-600">Excused</div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Attendance Status Card */}
          <Card className="col-span-1 md:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg font-medium">Attendance Status</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-20 w-full" />
              ) : (
                <div>
                  <div className="flex items-center justify-center h-20">
                    {stats.percentage >= 75 ? (
                      <div className="flex items-center text-green-600">
                        <CheckCircle className="h-10 w-10 mr-2" />
                        <div>
                          <div className="font-medium">Good Standing</div>
                          <div className="text-sm">Your attendance is above the required minimum</div>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center text-red-600">
                        <AlertCircle className="h-10 w-10 mr-2" />
                        <div>
                          <div className="font-medium">At Risk</div>
                          <div className="text-sm">Your attendance is below the 75% requirement</div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <CardTitle>Attendance Records</CardTitle>
              <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                <SelectTrigger className="w-full sm:w-[200px]">
                  <SelectValue placeholder="Subject" />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map((subject) => (
                    <SelectItem key={subject} value={subject}>
                      {subject}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="list" className="w-full">
              <TabsList className="mb-6">
                <TabsTrigger value="list">List View</TabsTrigger>
                <TabsTrigger value="calendar">Calendar View</TabsTrigger>
              </TabsList>
              
              <TabsContent value="list">
                {isLoading ? (
                  <Skeleton className="h-64 w-full" />
                ) : attendanceData && attendanceData.length > 0 ? (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Date</TableHead>
                          <TableHead>Subject</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {attendanceData.map((record: any) => (
                          <TableRow key={record.id}>
                            <TableCell>
                              {format(new Date(record.date), "PP")}
                            </TableCell>
                            <TableCell>{record.subject}</TableCell>
                            <TableCell>{getStatusBadge(record.status)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <CalendarCheck className="h-12 w-12 text-neutral-300 mx-auto mb-3" />
                    <p className="text-neutral-500">No attendance records found.</p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="calendar">
                <div className="text-center py-8">
                  <CalendarCheck className="h-12 w-12 text-neutral-300 mx-auto mb-3" />
                  <p className="text-neutral-500">Calendar view will be implemented soon.</p>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}
