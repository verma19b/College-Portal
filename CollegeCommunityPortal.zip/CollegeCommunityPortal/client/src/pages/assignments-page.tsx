import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/layout/app-shell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { FileInput, Clock, Calendar, FileCheck, AlertTriangle, Upload, Users, Layers, CheckCircle } from "lucide-react";
import { formatDistanceToNow, format, isPast } from "date-fns";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { insertAssignmentSubmissionSchema } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { CreateAssignmentDialog } from "@/components/assignments/create-assignment-dialog";

// Subject options
const subjects = [
  "All Subjects",
  "Data Structures",
  "Algorithms",
  "Database Systems",
  "Web Development",
  "Computer Networks",
  "Operating Systems",
  "Software Engineering"
];

// Extend the existing schema to add validation rules
const submitAssignmentSchema = insertAssignmentSubmissionSchema.extend({
  fileUrl: z.string().url("Must be a valid URL to your submission file"),
});

type SubmitAssignmentData = z.infer<typeof submitAssignmentSchema>;

export default function AssignmentsPage() {
  const [selectedSubject, setSelectedSubject] = useState<string>("All Subjects");
  const [selectedAssignment, setSelectedAssignment] = useState<any>(null);
  const [isSubmitDialogOpen, setIsSubmitDialogOpen] = useState<boolean>(false);
  const { toast } = useToast();
  const { user } = useAuth();
  
  // Check if user is faculty
  const isFaculty = user?.role === "faculty";
  
  // Fetch assignments
  const { data: assignments, isLoading } = useQuery({
    queryKey: [
      "/api/assignments", 
      { pending: true },
      selectedSubject !== "All Subjects" ? { subject: selectedSubject } : undefined
    ],
    // Using default query function
  });
  
  // Fetch user's submissions
  const { data: submissions, isLoading: isLoadingSubmissions } = useQuery({
    queryKey: ["/api/assignments/submissions/user"],
    // Using default query function
  });
  
  // Form for submitting assignments
  const form = useForm<SubmitAssignmentData>({
    resolver: zodResolver(submitAssignmentSchema),
    defaultValues: {
      assignmentId: 0,
      fileUrl: "",
    },
  });
  
  // Mutation for submitting assignments
  const submitAssignmentMutation = useMutation({
    mutationFn: async (data: SubmitAssignmentData) => {
      const res = await apiRequest("POST", `/api/assignments/${data.assignmentId}/submit`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/assignments/submissions/user"] });
      toast({
        title: "Success!",
        description: "Your assignment has been submitted.",
      });
      form.reset();
      setIsSubmitDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Check if assignment is already submitted
  const isSubmitted = (assignmentId: number) => {
    if (!submissions) return false;
    return submissions.some((submission: any) => submission.assignmentId === assignmentId);
  };
  
  // Find submission for an assignment
  const findSubmission = (assignmentId: number) => {
    if (!submissions) return null;
    return submissions.find((submission: any) => submission.assignmentId === assignmentId);
  };
  
  // Helper function to get badge for assignment status
  const getStatusBadge = (dueDate: string) => {
    const due = new Date(dueDate);
    const isPastDue = isPast(due);
    
    // If due date is past
    if (isPastDue) {
      return (
        <Badge variant="outline" className="bg-red-50 text-red-600 border-red-200">
          <AlertTriangle className="h-3 w-3 mr-1" />
          Overdue
        </Badge>
      );
    }
    
    // If due date is within 2 days
    const twoDaysFromNow = new Date();
    twoDaysFromNow.setDate(twoDaysFromNow.getDate() + 2);
    
    if (due <= twoDaysFromNow) {
      return (
        <Badge variant="outline" className="bg-amber-50 text-amber-600 border-amber-200">
          <Clock className="h-3 w-3 mr-1" />
          Due Soon
        </Badge>
      );
    }
    
    // Otherwise, it's upcoming
    return (
      <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
        <Calendar className="h-3 w-3 mr-1" />
        Upcoming
      </Badge>
    );
  };
  
  // Helper function to get badge for submission status
  const getSubmissionBadge = (status: string) => {
    switch (status) {
      case "submitted":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-600 border-green-200">
            <FileCheck className="h-3 w-3 mr-1" />
            Submitted
          </Badge>
        );
      case "late":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-600 border-amber-200">
            <Clock className="h-3 w-3 mr-1" />
            Late Submission
          </Badge>
        );
      case "graded":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-600 border-blue-200">
            <FileCheck className="h-3 w-3 mr-1" />
            Graded
          </Badge>
        );
      default:
        return (
          <Badge variant="outline">
            {status}
          </Badge>
        );
    }
  };
  
  // Handle opening submit dialog
  const handleOpenSubmitDialog = (assignment: any) => {
    setSelectedAssignment(assignment);
    form.setValue("assignmentId", assignment.id);
    setIsSubmitDialogOpen(true);
  };
  
  // Handle submit form
  function onSubmit(data: SubmitAssignmentData) {
    submitAssignmentMutation.mutate(data);
  }
  
  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">Assignments</h1>
            <p className="text-neutral-600">Manage and submit your course assignments</p>
          </div>
          
          {/* Show create assignment button for faculty users */}
          {isFaculty && (
            <div className="flex-shrink-0">
              <CreateAssignmentDialog />
            </div>
          )}
        </div>
        
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <CardTitle>Assignment Dashboard</CardTitle>
              <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                <SelectTrigger className="w-full sm:w-[200px]">
                  <SelectValue placeholder="Subject" />
                </SelectTrigger>
                <SelectContent>
                  {subjects.map((subject) => (
                    <SelectItem key={subject} value={subject}>
                      {subject}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="pending" className="w-full">
              <TabsList className="mb-6">
                <TabsTrigger value="pending">Pending</TabsTrigger>
                <TabsTrigger value="submitted">Submitted</TabsTrigger>
                <TabsTrigger value="all">All Assignments</TabsTrigger>
                {isFaculty && <TabsTrigger value="manage">Manage Submissions</TabsTrigger>}
              </TabsList>
              
              <TabsContent value="pending">
                {isLoading ? (
                  <Skeleton className="h-64 w-full" />
                ) : assignments && assignments.length > 0 ? (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Title</TableHead>
                          <TableHead>Subject</TableHead>
                          <TableHead>Due Date</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Action</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {assignments
                          .filter((assignment: any) => !isSubmitted(assignment.id))
                          .map((assignment: any) => (
                            <TableRow key={assignment.id}>
                              <TableCell className="font-medium">{assignment.title}</TableCell>
                              <TableCell>{assignment.subject}</TableCell>
                              <TableCell>
                                <div className="flex flex-col">
                                  <span>{format(new Date(assignment.dueDate), "MMMM d, yyyy")}</span>
                                  <span className="text-xs text-neutral-500">
                                    {formatDistanceToNow(new Date(assignment.dueDate), { addSuffix: true })}
                                  </span>
                                </div>
                              </TableCell>
                              <TableCell>{getStatusBadge(assignment.dueDate)}</TableCell>
                              <TableCell>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="text-primary hover:bg-primary/10 border-primary"
                                  onClick={() => handleOpenSubmitDialog(assignment)}
                                >
                                  <Upload className="h-4 w-4 mr-2" />
                                  Submit
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <FileCheck className="h-12 w-12 text-neutral-300 mx-auto mb-3" />
                    <p className="text-neutral-500">No pending assignments found.</p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="submitted">
                {isLoadingSubmissions ? (
                  <Skeleton className="h-64 w-full" />
                ) : submissions && submissions.length > 0 ? (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Assignment</TableHead>
                          <TableHead>Submitted On</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Grade</TableHead>
                          <TableHead>Action</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {submissions.map((submission: any) => (
                          <TableRow key={submission.id}>
                            <TableCell className="font-medium">
                              {submission.assignment?.title || "Unknown Assignment"}
                            </TableCell>
                            <TableCell>
                              <div className="flex flex-col">
                                <span>{format(new Date(submission.submittedAt), "MMMM d, yyyy")}</span>
                                <span className="text-xs text-neutral-500">
                                  {formatDistanceToNow(new Date(submission.submittedAt), { addSuffix: true })}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell>{getSubmissionBadge(submission.status)}</TableCell>
                            <TableCell>
                              {submission.grade || "-"}
                            </TableCell>
                            <TableCell>
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-neutral-600 hover:bg-neutral-100"
                                onClick={() => window.open(submission.fileUrl, '_blank')}
                              >
                                View
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <FileInput className="h-12 w-12 text-neutral-300 mx-auto mb-3" />
                    <p className="text-neutral-500">No submitted assignments found.</p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="all">
                <div className="text-center py-8">
                  <FileInput className="h-12 w-12 text-neutral-300 mx-auto mb-3" />
                  <p className="text-neutral-500">All assignments will be shown here.</p>
                </div>
              </TabsContent>
              
              {/* Faculty-only tab to manage student submissions */}
              {isFaculty && (
                <TabsContent value="manage">
                  <div className="space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                      <h3 className="text-lg font-medium">Student Submissions</h3>
                      <Select defaultValue="all">
                        <SelectTrigger className="w-full sm:w-[200px]">
                          <SelectValue placeholder="Filter by Assignment" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Assignments</SelectItem>
                          {assignments?.map((assignment: any) => (
                            <SelectItem key={assignment.id} value={assignment.id.toString()}>
                              {assignment.title}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="rounded-md border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Student</TableHead>
                            <TableHead>Assignment</TableHead>
                            <TableHead>Submission Date</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>Grade</TableHead>
                            <TableHead>Actions</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          <TableRow>
                            <TableCell colSpan={6} className="h-24 text-center">
                              <Users className="h-8 w-8 text-neutral-300 mx-auto mb-3" />
                              <p className="text-neutral-500">No student submissions yet.</p>
                              <p className="text-neutral-400 text-sm">
                                Student submissions will appear here when available.
                              </p>
                            </TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                </TabsContent>
              )}
            </Tabs>
          </CardContent>
        </Card>
      </div>
      
      {/* Submit Assignment Dialog */}
      <Dialog open={isSubmitDialogOpen} onOpenChange={setIsSubmitDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Submit Assignment</DialogTitle>
            <DialogDescription>
              {selectedAssignment && (
                <div className="mt-2">
                  <div className="font-medium">{selectedAssignment.title}</div>
                  <div className="text-sm mt-1">
                    Due: {format(new Date(selectedAssignment.dueDate), "MMMM d, yyyy 'at' h:mm a")}
                    {isPast(new Date(selectedAssignment.dueDate)) && (
                      <span className="text-red-500 ml-2">
                        (Overdue)
                      </span>
                    )}
                  </div>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-4">
              <FormField
                control={form.control}
                name="fileUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Submission URL</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="https://drive.google.com/file/your-assignment"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsSubmitDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={submitAssignmentMutation.isPending}
                >
                  {submitAssignmentMutation.isPending ? "Submitting..." : "Submit Assignment"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}
