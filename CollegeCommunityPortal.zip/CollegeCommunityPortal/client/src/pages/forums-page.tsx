import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ForumPostCard } from "@/components/forums/forum-post-card";
import { CreatePostDialog } from "@/components/forums/create-post-dialog";
import { AppShell } from "@/components/layout/app-shell";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";

// Forum categories
const categories = [
  "All",
  "Algorithms",
  "Projects",
  "Web Development",
  "Machine Learning",
  "Internships",
  "Placements",
  "Campus Events",
  "General"
];

export default function ForumsPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState<string>("");
  
  // Fetch all forum posts
  const { data: forumPosts, isLoading } = useQuery({
    queryKey: ["/api/forums", selectedCategory !== "All" ? { category: selectedCategory } : undefined],
    // Using default query function
  });
  
  // Filter posts by search query
  const filteredPosts = forumPosts?.filter((post: any) => {
    if (!searchQuery) return true;
    
    const query = searchQuery.toLowerCase();
    return (
      post.title.toLowerCase().includes(query) ||
      post.content.toLowerCase().includes(query) ||
      post.user?.firstName.toLowerCase().includes(query) ||
      post.user?.lastName.toLowerCase().includes(query)
    );
  });
  
  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-neutral-900">Forums</h1>
            <p className="text-neutral-600">Discuss topics, ask questions, and connect with peers</p>
          </div>
          
          <CreatePostDialog />
        </div>
        
        <div className="bg-white shadow-sm rounded-lg p-6">
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-neutral-400" />
              </div>
              <Input
                type="text"
                placeholder="Search forums..."
                className="pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <div className="w-full sm:w-64">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Filter by category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Tabs defaultValue="recent" className="w-full">
            <TabsList className="mb-6">
              <TabsTrigger value="recent">Recent</TabsTrigger>
              <TabsTrigger value="popular">Popular</TabsTrigger>
              <TabsTrigger value="unanswered">Unanswered</TabsTrigger>
            </TabsList>
            
            <TabsContent value="recent" className="space-y-4">
              {isLoading ? (
                Array(5).fill(0).map((_, i) => (
                  <div key={i} className="mb-4">
                    <Skeleton className="h-[200px] w-full rounded-lg" />
                  </div>
                ))
              ) : filteredPosts && filteredPosts.length > 0 ? (
                filteredPosts.map((post: any) => (
                  <ForumPostCard 
                    key={post.id} 
                    post={post} 
                    commentsCount={12} 
                    viewsCount={48} 
                  />
                ))
              ) : (
                <div className="text-center py-8">
                  <p className="text-neutral-500">No forum posts found.</p>
                  {searchQuery && (
                    <p className="text-neutral-400 mt-2">
                      Try adjusting your search or category filter.
                    </p>
                  )}
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="popular">
              <div className="text-center py-8">
                <p className="text-neutral-500">Popular posts will be shown here.</p>
              </div>
            </TabsContent>
            
            <TabsContent value="unanswered">
              <div className="text-center py-8">
                <p className="text-neutral-500">Unanswered questions will be shown here.</p>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </AppShell>
  );
}
