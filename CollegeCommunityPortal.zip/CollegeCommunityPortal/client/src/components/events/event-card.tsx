import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { Calendar, Clock, MapPin, Users } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface EventCardProps {
  event: {
    id: number;
    title: string;
    description: string;
    date: string;
    endDate: string;
    location: string;
    category: string;
    organizer: string;
  };
  userRsvp?: {
    status: string;
  };
  compact?: boolean;
}

export function EventCard({ event, userRsvp, compact = false }: EventCardProps) {
  const { toast } = useToast();
  const eventDate = new Date(event.date);
  const endDate = new Date(event.endDate);
  
  // Get appropriate badge color based on category
  const getBadgeClass = () => {
    switch (event.category.toLowerCase()) {
      case "workshop":
        return "bg-primary/10 text-primary";
      case "seminar":
      case "orientation":
        return "bg-secondary/10 text-secondary";
      case "cultural":
      case "talk":
        return "bg-accent/10 text-accent";
      default:
        return "bg-neutral-200 text-neutral-700";
    }
  };
  
  const rsvpMutation = useMutation({
    mutationFn: async ({ status }: { status: string }) => {
      const res = await apiRequest("POST", `/api/events/${event.id}/rsvp`, { status });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      toast({
        title: "RSVP Confirmed",
        description: `You're now ${rsvpMutation.variables?.status === "going" ? "attending" : "not attending"} this event.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const handleRsvp = (status: string) => {
    rsvpMutation.mutate({ status });
  };
  
  if (compact) {
    return (
      <div className="p-4 hover:bg-neutral-50">
        <div className="flex space-x-4">
          <div className="flex-shrink-0">
            <div className={`h-14 w-14 ${getBadgeClass()} rounded flex flex-col items-center justify-center`}>
              <span className="text-lg font-bold">{format(eventDate, "dd")}</span>
              <span className="text-xs font-medium">{format(eventDate, "MMM").toUpperCase()}</span>
            </div>
          </div>
          <div className="min-w-0 flex-1">
            <h4 className="text-base font-medium text-neutral-900 truncate">{event.title}</h4>
            <div className="mt-1 flex items-center text-sm text-neutral-500">
              <Clock className="h-4 w-4 text-neutral-400 mr-1" />
              {format(eventDate, "h:mm a")} - {format(endDate, "h:mm a")}
            </div>
            <div className="mt-1 flex items-center text-sm text-neutral-500">
              <MapPin className="h-4 w-4 text-neutral-400 mr-1" />
              {event.location}
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <Card className="mb-4 hover:shadow-md transition-shadow duration-200">
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row md:items-start">
          <div className="flex-shrink-0 mb-4 md:mb-0 md:mr-6">
            <div className={`h-20 w-20 ${getBadgeClass()} rounded-lg flex flex-col items-center justify-center`}>
              <span className="text-2xl font-bold">{format(eventDate, "dd")}</span>
              <span className="text-sm font-medium">{format(eventDate, "MMM").toUpperCase()}</span>
              <span className="text-xs">{format(eventDate, "yyyy")}</span>
            </div>
          </div>
          
          <div className="flex-1">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
              <h3 className="text-xl font-semibold text-neutral-900 mb-2 md:mb-0">{event.title}</h3>
              <Badge variant="outline" className={getBadgeClass()}>
                {event.category}
              </Badge>
            </div>
            
            <p className="text-neutral-600 mb-4">{event.description}</p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
              <div className="flex items-center text-sm text-neutral-600">
                <Clock className="h-4 w-4 text-neutral-400 mr-2" />
                <span>
                  {format(eventDate, "EEEE, MMMM d")}<br />
                  {format(eventDate, "h:mm a")} - {format(endDate, "h:mm a")}
                </span>
              </div>
              
              <div className="flex items-center text-sm text-neutral-600">
                <MapPin className="h-4 w-4 text-neutral-400 mr-2" />
                <span>{event.location}</span>
              </div>
              
              <div className="flex items-center text-sm text-neutral-600">
                <Users className="h-4 w-4 text-neutral-400 mr-2" />
                <span>Organized by: {event.organizer}</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="px-6 py-4 bg-neutral-50 border-t flex justify-end">
        {userRsvp ? (
          userRsvp.status === "going" ? (
            <div className="flex gap-2">
              <Badge variant="outline" className="bg-accent/10 text-accent border-none">
                You're attending
              </Badge>
              <Button 
                variant="outline" 
                size="sm" 
                className="text-red-500 border-red-500 hover:bg-red-50"
                onClick={() => handleRsvp("not_going")}
                disabled={rsvpMutation.isPending}
              >
                Cancel
              </Button>
            </div>
          ) : (
            <Button 
              variant="outline" 
              size="sm" 
              className="text-accent border-accent hover:bg-accent/10"
              onClick={() => handleRsvp("going")}
              disabled={rsvpMutation.isPending}
            >
              Attend
            </Button>
          )
        ) : (
          <Button 
            variant="outline" 
            size="sm" 
            className="text-primary border-primary hover:bg-primary/10"
            onClick={() => handleRsvp("going")}
            disabled={rsvpMutation.isPending}
          >
            <Calendar className="h-4 w-4 mr-2" />
            RSVP
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}
