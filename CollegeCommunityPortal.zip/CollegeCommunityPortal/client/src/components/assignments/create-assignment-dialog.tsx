import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertAssignmentSchema } from "@shared/schema";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { CalendarIcon, FileInput, BookOpen } from "lucide-react";
import { format } from "date-fns";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";

// MANIT Bhopal departments with their respective subjects
const departmentSubjects = {
  cse: [
    "Data Structures and Algorithms",
    "Object Oriented Programming",
    "Database Management Systems",
    "Computer Networks",
    "Operating Systems",
    "Software Engineering",
    "Web Development",
    "Machine Learning",
    "Artificial Intelligence",
    "Computer Architecture"
  ],
  ece: [
    "Digital Electronics",
    "Analog Circuits",
    "Signals and Systems",
    "Communication Systems",
    "Microprocessors",
    "Control Systems",
    "VLSI Design",
    "Embedded Systems"
  ],
  ee: [
    "Electrical Machines",
    "Power Systems",
    "Control Systems",
    "Power Electronics",
    "Electric Drives",
    "High Voltage Engineering"
  ],
  me: [
    "Thermodynamics",
    "Fluid Mechanics", 
    "Machine Design",
    "Heat Transfer",
    "Manufacturing Processes",
    "Robotics and Automation"
  ],
  ce: [
    "Structural Analysis",
    "Construction Technology",
    "Geotechnical Engineering",
    "Transportation Engineering",
    "Environmental Engineering",
    "Surveying"
  ],
  chem: [
    "Chemical Processes",
    "Process Control",
    "Chemical Reaction Engineering",
    "Thermodynamics",
    "Mass Transfer",
    "Fluid Mechanics"
  ],
  mme: [
    "Material Science",
    "Metallurgy",
    "Non-destructive Testing",
    "Physical Metallurgy",
    "Mechanical Behavior of Materials"
  ],
  first_year: [
    "Engineering Mathematics",
    "Engineering Physics",
    "Engineering Chemistry",
    "Basic Electrical Engineering",
    "Programming Fundamentals",
    "Engineering Graphics",
    "Engineering Mechanics",
    "Communication Skills"
  ]
};

// Extend the existing schema to add validation rules
const createAssignmentSchema = insertAssignmentSchema.extend({
  title: z.string().min(5, "Title must be at least 5 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  dueDate: z.date({
    required_error: "Please select a due date",
  }),
  subject: z.string().min(1, "Please select a subject"),
  department: z.string().min(1, "Please select a department"),
  batch: z.string().min(1, "Please select a batch"),
  section: z.string().optional()
});

type CreateAssignmentData = z.infer<typeof createAssignmentSchema>;

export function CreateAssignmentDialog() {
  const [open, setOpen] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState<string>("");
  const { toast } = useToast();
  const { user } = useAuth();
  
  // Check if user is faculty
  const isFaculty = user?.role === "faculty";
  
  const form = useForm<CreateAssignmentData>({
    resolver: zodResolver(createAssignmentSchema),
    defaultValues: {
      title: "",
      description: "",
      subject: "",
      department: "",
      batch: "",
      section: ""
    },
  });
  
  const createAssignmentMutation = useMutation({
    mutationFn: async (data: CreateAssignmentData) => {
      const res = await apiRequest("POST", "/api/assignments", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/assignments"] });
      toast({
        title: "Success!",
        description: "Assignment has been created.",
      });
      form.reset();
      setOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  function onSubmit(data: CreateAssignmentData) {
    // Include createdBy field (user ID)
    const assignmentData = {
      ...data,
      createdBy: user?.id || 0,
    };
    createAssignmentMutation.mutate(assignmentData);
  }
  
  // Handle department change for subject filtering
  const handleDepartmentChange = (value: string) => {
    form.setValue("department", value);
    setSelectedDepartment(value);
    // Reset subject when department changes
    form.setValue("subject", "");
  };
  
  // Generate years for batch selection (current year-5 to current year)
  const generateYearOptions = () => {
    const currentYear = new Date().getFullYear();
    const years = [];
    for (let i = 0; i <= 5; i++) {
      years.push(currentYear - i);
    }
    return years;
  };
  
  // Only display for faculty users
  if (!isFaculty) {
    return null;
  }
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <FileInput className="h-4 w-4" />
          Create Assignment
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Create New Assignment</DialogTitle>
          <DialogDescription>
            Create a new assignment for MANIT Bhopal students. Students will be able to submit their 
            work before the deadline.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Assignment Title</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter a descriptive title" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="department"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Department</FormLabel>
                    <Select 
                      onValueChange={handleDepartmentChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select department" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="cse">Computer Science & Engineering</SelectItem>
                        <SelectItem value="ece">Electronics & Communication</SelectItem>
                        <SelectItem value="ee">Electrical Engineering</SelectItem>
                        <SelectItem value="me">Mechanical Engineering</SelectItem>
                        <SelectItem value="ce">Civil Engineering</SelectItem>
                        <SelectItem value="chem">Chemical Engineering</SelectItem>
                        <SelectItem value="mme">Metallurgy & Materials Engineering</SelectItem>
                        <SelectItem value="first_year">First Year (Common)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="subject"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subject</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                      disabled={!selectedDepartment}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder={selectedDepartment ? "Select subject" : "Select department first"} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {selectedDepartment && departmentSubjects[selectedDepartment as keyof typeof departmentSubjects].map(subject => (
                          <SelectItem key={subject} value={subject}>
                            {subject}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="batch"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Batch/Year</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select batch year" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {generateYearOptions().map(year => (
                          <SelectItem key={year} value={year.toString()}>
                            {year}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="section"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Section (Optional)</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select section" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {["A", "B", "C", "D", "E", "All Sections"].map(section => (
                          <SelectItem key={section} value={section}>
                            {section}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Describe the assignment requirements..." 
                      className="min-h-[100px]" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="dueDate"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Due Date</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={"outline"}
                          className={cn(
                            "w-full pl-3 text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          {field.value ? (
                            format(field.value, "PPP")
                          ) : (
                            <span>Pick a date</span>
                          )}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        disabled={(date) =>
                          // Disable dates in the past
                          date < new Date()
                        }
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setOpen(false)}
                className="mt-2"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={createAssignmentMutation.isPending}
                className="mt-2"
              >
                {createAssignmentMutation.isPending ? "Creating..." : "Create Assignment"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}