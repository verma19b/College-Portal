import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { CheckCircle, PenTool, Calendar, MessageSquare } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export function RecentActivity() {
  const { data: activities, isLoading } = useQuery({
    queryKey: ["/api/activities/recent"],
    // Using default query function
  });

  // Helper function to get activity icon and color based on type
  const getActivityDetails = (activity: any) => {
    switch (activity.type) {
      case "assignment_submission":
        return {
          icon: CheckCircle,
          bgColor: "bg-primary/10",
          textColor: "text-primary",
          title: `Assignment submitted: ${activity.data.assignmentTitle}`,
          description: `Submitted ${activity.data.status === "late" ? "late" : "on time"} - ${formatDistanceToNow(new Date(activity.createdAt))} ago`
        };
      case "event_rsvp":
        return {
          icon: Calendar,
          bgColor: "bg-secondary/10",
          textColor: "text-secondary",
          title: `Event RSVP: ${activity.data.eventTitle}`,
          description: `You've registered for this event - ${formatDistanceToNow(new Date(activity.createdAt))} ago`
        };
      case "forum_comment":
      case "forum_post":
        return {
          icon: MessageSquare,
          bgColor: "bg-accent/10",
          textColor: "text-accent",
          title: `Forum ${activity.type === "forum_post" ? "post" : "reply"}: ${activity.data.title || ""}`,
          description: `You ${activity.type === "forum_post" ? "posted" : "replied to"} a ${activity.type === "forum_post" ? "topic" : "question"} - ${formatDistanceToNow(new Date(activity.createdAt))} ago`
        };
      default:
        return {
          icon: PenTool,
          bgColor: "bg-neutral-200",
          textColor: "text-neutral-700",
          title: "Activity",
          description: `${formatDistanceToNow(new Date(activity.createdAt))} ago`
        };
    }
  };

  return (
    <Card>
      <CardHeader className="px-6 py-4 border-b border-neutral-200">
        <CardTitle className="text-lg font-medium text-neutral-900">Recent Activity</CardTitle>
      </CardHeader>
      
      <CardContent className="p-0 divide-y divide-neutral-200">
        {isLoading ? (
          Array(3).fill(0).map((_, i) => (
            <div key={i} className="p-6 flex space-x-4">
              <Skeleton className="h-10 w-10 rounded-full" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
              </div>
            </div>
          ))
        ) : activities && activities.length > 0 ? (
          activities.slice(0, 3).map((activity: any) => {
            const { icon: Icon, bgColor, textColor, title, description } = getActivityDetails(activity);
            
            return (
              <div key={activity.id} className="p-6 flex space-x-4">
                <div className="flex-shrink-0">
                  <span className={`h-10 w-10 rounded-full ${bgColor} flex items-center justify-center`}>
                    <Icon className={`h-5 w-5 ${textColor}`} />
                  </span>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-neutral-900">
                    {title}
                  </p>
                  <p className="text-sm text-neutral-500">
                    {description}
                  </p>
                </div>
              </div>
            );
          })
        ) : (
          <div className="p-6 text-center text-neutral-500">
            No recent activities found.
          </div>
        )}
      </CardContent>
      
      <CardFooter className="p-4 bg-neutral-50 text-center">
        <Link href="/activities" className="text-sm font-medium text-primary hover:text-primary-dark">
          View all activity
        </Link>
      </CardFooter>
    </Card>
  );
}
