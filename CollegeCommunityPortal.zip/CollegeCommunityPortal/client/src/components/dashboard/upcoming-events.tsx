import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { Clock, MapPin } from "lucide-react";
import { format } from "date-fns";

export function UpcomingEvents() {
  const { data: events, isLoading } = useQuery({
    queryKey: ["/api/events", { upcoming: true }],
    // Using default query function
  });

  // Helper function to get event color based on category
  const getEventColor = (category: string) => {
    switch (category?.toLowerCase()) {
      case "workshop":
        return "bg-primary/10 text-primary";
      case "seminar":
      case "orientation":
        return "bg-secondary/10 text-secondary";
      case "cultural":
      case "talk":
        return "bg-accent/10 text-accent";
      default:
        return "bg-neutral-200 text-neutral-700";
    }
  };

  return (
    <Card>
      <CardHeader className="px-6 py-4 border-b border-neutral-200 flex justify-between items-center">
        <CardTitle className="text-lg font-medium text-neutral-900">Upcoming Events</CardTitle>
        <Link href="/events" className="text-sm font-medium text-primary hover:text-primary-dark">
          View all
        </Link>
      </CardHeader>
      
      <CardContent className="p-0 divide-y divide-neutral-200">
        {isLoading ? (
          Array(3).fill(0).map((_, i) => (
            <div key={i} className="p-4">
              <div className="flex space-x-4">
                <Skeleton className="h-14 w-14 rounded" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-1/2" />
                  <Skeleton className="h-3 w-2/3" />
                </div>
              </div>
            </div>
          ))
        ) : events && events.length > 0 ? (
          events.slice(0, 3).map((event: any) => {
            const eventDate = new Date(event.date);
            const colorClass = getEventColor(event.category);
            
            return (
              <div key={event.id} className="p-4 hover:bg-neutral-50">
                <div className="flex space-x-4">
                  <div className="flex-shrink-0">
                    <div className={`h-14 w-14 ${colorClass} rounded flex flex-col items-center justify-center`}>
                      <span className="text-lg font-bold">{format(eventDate, "dd")}</span>
                      <span className="text-xs font-medium">{format(eventDate, "MMM").toUpperCase()}</span>
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <h4 className="text-base font-medium text-neutral-900 truncate">{event.title}</h4>
                    <div className="mt-1 flex items-center text-sm text-neutral-500">
                      <Clock className="h-4 w-4 text-neutral-400 mr-1" />
                      {format(eventDate, "h:mm a")} - {format(new Date(event.endDate), "h:mm a")}
                    </div>
                    <div className="mt-1 flex items-center text-sm text-neutral-500">
                      <MapPin className="h-4 w-4 text-neutral-400 mr-1" />
                      {event.location}
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="p-6 text-center text-neutral-500">
            No upcoming events found.
          </div>
        )}
      </CardContent>
      
      <CardFooter className="p-4 bg-neutral-50 text-center">
        <Link href="/events" className="text-sm font-medium text-primary hover:text-primary-dark">
          View all events
        </Link>
      </CardFooter>
    </Card>
  );
}
