import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { Bus, Map as MapIcon } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export function BusTracker() {
  const { data: buses, isLoading } = useQuery({
    queryKey: ["/api/buses"],
    // Using default query function
  });

  return (
    <Card>
      <CardHeader className="px-6 py-4 border-b border-neutral-200">
        <CardTitle className="text-lg font-medium text-neutral-900">Campus Bus Tracker</CardTitle>
      </CardHeader>
      
      <CardContent className="p-6">
        {/* Campus Map Placeholder */}
        <div className="bg-neutral-100 h-40 rounded-lg flex items-center justify-center">
          <div className="text-center">
            <MapIcon className="mx-auto h-8 w-8 text-neutral-400" />
            <p className="mt-2 text-sm text-neutral-500">Campus Map</p>
          </div>
        </div>
        
        <div className="mt-4">
          <h4 className="font-medium text-sm text-neutral-900 mb-2">Nearest Buses</h4>
          
          {isLoading ? (
            Array(2).fill(0).map((_, i) => (
              <div key={i} className="mb-2">
                <Skeleton className="h-16 w-full rounded-lg" />
              </div>
            ))
          ) : buses && buses.length > 0 ? (
            <div className="space-y-2">
              {buses.slice(0, 2).map((bus: any) => {
                const arrivalTime = new Date(bus.estimatedArrival);
                const timeRemaining = formatDistanceToNow(arrivalTime, { addSuffix: false });
                
                return (
                  <div key={bus.id} className="flex items-center p-3 bg-neutral-50 rounded-lg">
                    <Bus className="h-5 w-5 text-primary mr-2" />
                    <div>
                      <p className="text-sm font-medium text-neutral-900">Bus #{bus.busNumber}</p>
                      <p className="text-xs text-neutral-500">
                        Arriving in ~{timeRemaining} at {bus.nextStop}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-4 text-center text-neutral-500">
              No bus information available.
            </div>
          )}
        </div>
        
        <div className="mt-4 text-center">
          <Link href="/bus-tracker" className="text-sm font-medium text-primary hover:text-primary-dark">
            View all routes
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
