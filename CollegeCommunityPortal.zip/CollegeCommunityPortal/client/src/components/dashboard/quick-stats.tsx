import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { CalendarCheck, FileText, Calendar, MessageSquare } from "lucide-react";

export function QuickStats() {
  // Fetch attendance data
  const { data: attendanceData, isLoading: attendanceLoading } = useQuery({
    queryKey: ["/api/attendance"],
    // Using default query function
  });

  // Fetch assignments data
  const { data: assignmentsData, isLoading: assignmentsLoading } = useQuery({
    queryKey: ["/api/assignments", { pending: true }],
    // Using default query function
  });

  // Fetch events data
  const { data: eventsData, isLoading: eventsLoading } = useQuery({
    queryKey: ["/api/events", { upcoming: true }],
    // Using default query function
  });

  // Fetch forums data
  const { data: forumsData, isLoading: forumsLoading } = useQuery({
    queryKey: ["/api/forums"],
    // Using default query function
  });

  // Calculate attendance percentage (example calculation)
  const calculateAttendancePercentage = () => {
    if (!attendanceData || attendanceData.length === 0) return "N/A";
    
    const totalClasses = attendanceData.length;
    const presentClasses = attendanceData.filter(
      (record: any) => record.status === "present"
    ).length;
    
    const percentage = (presentClasses / totalClasses) * 100;
    return `${Math.round(percentage)}%`;
  };

  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {/* Attendance */}
      <Card>
        <CardContent className="p-5">
          <div className="flex items-center">
            <div className="flex-shrink-0 bg-primary/10 rounded-md p-3">
              <CalendarCheck className="h-5 w-5 text-primary" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-neutral-500 truncate">Attendance</dt>
                <dd>
                  {attendanceLoading ? (
                    <Skeleton className="h-7 w-16" />
                  ) : (
                    <div className="text-lg font-semibold text-neutral-900">
                      {calculateAttendancePercentage()}
                    </div>
                  )}
                </dd>
              </dl>
            </div>
          </div>
        </CardContent>
        <CardFooter className="bg-neutral-50 px-5 py-3">
          <div className="text-sm">
            <Link href="/attendance" className="font-medium text-primary hover:text-primary-dark">
              View details
            </Link>
          </div>
        </CardFooter>
      </Card>
      
      {/* Pending Assignments */}
      <Card>
        <CardContent className="p-5">
          <div className="flex items-center">
            <div className="flex-shrink-0 bg-secondary/10 rounded-md p-3">
              <FileText className="h-5 w-5 text-secondary" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-neutral-500 truncate">Pending Assignments</dt>
                <dd>
                  {assignmentsLoading ? (
                    <Skeleton className="h-7 w-8" />
                  ) : (
                    <div className="text-lg font-semibold text-neutral-900">
                      {assignmentsData?.length || 0}
                    </div>
                  )}
                </dd>
              </dl>
            </div>
          </div>
        </CardContent>
        <CardFooter className="bg-neutral-50 px-5 py-3">
          <div className="text-sm">
            <Link href="/assignments" className="font-medium text-primary hover:text-primary-dark">
              View details
            </Link>
          </div>
        </CardFooter>
      </Card>
      
      {/* Upcoming Events */}
      <Card>
        <CardContent className="p-5">
          <div className="flex items-center">
            <div className="flex-shrink-0 bg-accent/10 rounded-md p-3">
              <Calendar className="h-5 w-5 text-accent" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-neutral-500 truncate">Upcoming Events</dt>
                <dd>
                  {eventsLoading ? (
                    <Skeleton className="h-7 w-8" />
                  ) : (
                    <div className="text-lg font-semibold text-neutral-900">
                      {eventsData?.length || 0}
                    </div>
                  )}
                </dd>
              </dl>
            </div>
          </div>
        </CardContent>
        <CardFooter className="bg-neutral-50 px-5 py-3">
          <div className="text-sm">
            <Link href="/events" className="font-medium text-primary hover:text-primary-dark">
              View details
            </Link>
          </div>
        </CardFooter>
      </Card>
      
      {/* Unread Forum Posts */}
      <Card>
        <CardContent className="p-5">
          <div className="flex items-center">
            <div className="flex-shrink-0 bg-neutral-200 rounded-md p-3">
              <MessageSquare className="h-5 w-5 text-neutral-700" />
            </div>
            <div className="ml-5 w-0 flex-1">
              <dl>
                <dt className="text-sm font-medium text-neutral-500 truncate">Forum Posts</dt>
                <dd>
                  {forumsLoading ? (
                    <Skeleton className="h-7 w-8" />
                  ) : (
                    <div className="text-lg font-semibold text-neutral-900">
                      {forumsData?.length || 0}
                    </div>
                  )}
                </dd>
              </dl>
            </div>
          </div>
        </CardContent>
        <CardFooter className="bg-neutral-50 px-5 py-3">
          <div className="text-sm">
            <Link href="/forums" className="font-medium text-primary hover:text-primary-dark">
              View details
            </Link>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}
