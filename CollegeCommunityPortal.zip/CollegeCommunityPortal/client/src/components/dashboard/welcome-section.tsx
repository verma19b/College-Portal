import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { format } from "date-fns";

export function WelcomeSection() {
  const { user } = useAuth();

  if (!user) return null;

  const lastLogin = user.lastLogin ? new Date(user.lastLogin) : null;
  const formattedLastLogin = lastLogin 
    ? `${format(lastLogin, "EEEE, h:mm a")}`
    : "First login";

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center">
          <h2 className="text-xl font-bold text-neutral-900">
            Welcome back, {user.firstName}!
          </h2>
          <div className="ml-auto">
            <span className="text-sm text-neutral-500">
              Last login: {formattedLastLogin}
            </span>
          </div>
        </div>
        <p className="mt-2 text-neutral-600">
          Your dashboard shows your academic progress and upcoming events.
        </p>
      </CardContent>
    </Card>
  );
}
