import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Link } from "wouter";
import { getInitials } from "@/lib/utils";

// Sample data for alumni (in a real app, this would come from an API)
const alumni = [
  {
    id: 1,
    name: "Michael Torres",
    batch: "2021 CSE",
    position: "Software Engineer @ Google",
    avatar: "",
  },
  {
    id: 2,
    name: "Priya Sharma",
    batch: "2020 CSE",
    position: "ML Engineer @ Microsoft",
    avatar: "",
  },
  {
    id: 3,
    name: "David Kim",
    batch: "2021 CSE",
    position: "Product Manager @ Amazon",
    avatar: "",
  },
];

export function SeniorConnect() {
  return (
    <Card>
      <CardHeader className="px-6 py-4 border-b border-neutral-200">
        <CardTitle className="text-lg font-medium text-neutral-900">Connect with Seniors</CardTitle>
      </CardHeader>
      
      <CardContent className="p-6">
        <div className="space-y-4">
          {alumni.map((person) => (
            <div key={person.id} className="flex items-center p-3 border border-neutral-200 rounded-lg hover:bg-neutral-50">
              <Avatar>
                <AvatarImage src={person.avatar} alt={person.name} />
                <AvatarFallback className="bg-neutral-300">
                  {getInitials(person.name)}
                </AvatarFallback>
              </Avatar>
              <div className="ml-3">
                <p className="text-sm font-medium text-neutral-900">{person.name}</p>
                <p className="text-xs text-neutral-500">{person.batch} • {person.position}</p>
              </div>
              <Button 
                variant="ghost" 
                size="sm"
                className="ml-auto flex-shrink-0 text-sm font-medium text-primary hover:text-primary-dark"
              >
                Connect
              </Button>
            </div>
          ))}
        </div>
        
        <div className="mt-6 text-center">
          <Link href="/connect" className="text-sm font-medium text-primary hover:text-primary-dark">
            View all alumni
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
