import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { MessageCircle, Eye } from "lucide-react";
import { getInitials } from "@/lib/utils";

export function ForumTopics() {
  const { data: forumTopics, isLoading } = useQuery({
    queryKey: ["/api/forums"],
    // Using default query function
  });

  return (
    <Card>
      <CardHeader className="px-6 py-4 border-b border-neutral-200 flex justify-between items-center">
        <CardTitle className="text-lg font-medium text-neutral-900">Popular Forum Topics</CardTitle>
        <Link href="/forums" className="text-sm font-medium text-primary hover:text-primary-dark">
          View all forums
        </Link>
      </CardHeader>
      
      <CardContent className="p-0 divide-y divide-neutral-200">
        {isLoading ? (
          Array(2).fill(0).map((_, i) => (
            <div key={i} className="p-6 space-y-3">
              <div className="flex items-center justify-between">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-6 w-20 rounded-full" />
              </div>
              <Skeleton className="h-10 w-full" />
              <div className="flex justify-between">
                <Skeleton className="h-8 w-32" />
                <Skeleton className="h-4 w-20" />
              </div>
            </div>
          ))
        ) : forumTopics && forumTopics.length > 0 ? (
          forumTopics.slice(0, 2).map((topic: any) => (
            <div key={topic.id} className="p-6">
              <div className="flex items-center justify-between">
                <h4 className="text-base font-medium text-neutral-900">{topic.title}</h4>
                <Badge variant="outline" className="bg-primary/10 text-primary border-none">
                  {topic.category}
                </Badge>
              </div>
              <p className="mt-1 text-sm text-neutral-600 line-clamp-2">
                {topic.content}
              </p>
              <div className="mt-2 flex items-center justify-between">
                <div className="flex items-center text-sm text-neutral-500">
                  <Avatar className="h-6 w-6 mr-2">
                    <AvatarImage src={topic.user?.avatar} alt={`${topic.user?.firstName} ${topic.user?.lastName}`} />
                    <AvatarFallback className="text-xs">
                      {getInitials(`${topic.user?.firstName || ''} ${topic.user?.lastName || ''}`)}
                    </AvatarFallback>
                  </Avatar>
                  <span>
                    Posted by <span className="font-medium">{topic.user?.firstName} {topic.user?.lastName}</span> • {topic.user?.batch}
                  </span>
                </div>
                <div className="flex items-center space-x-4">
                  <span className="flex items-center text-sm text-neutral-500">
                    <MessageCircle className="h-4 w-4 text-neutral-400 mr-1" />
                    12
                  </span>
                  <span className="flex items-center text-sm text-neutral-500">
                    <Eye className="h-4 w-4 text-neutral-400 mr-1" />
                    48
                  </span>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="p-6 text-center text-neutral-500">
            No forum topics found.
          </div>
        )}
      </CardContent>
      
      <CardFooter className="p-4 bg-neutral-50 text-center">
        <Link href="/forums" className="text-sm font-medium text-primary hover:text-primary-dark">
          View all topics
        </Link>
      </CardFooter>
    </Card>
  );
}
