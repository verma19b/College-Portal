import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { formatDistanceToNow } from "date-fns";
import { MessageCircle, Eye, Calendar } from "lucide-react";
import { getInitials } from "@/lib/utils";
import { Link } from "wouter";

interface ForumPostCardProps {
  post: {
    id: number;
    title: string;
    content: string;
    category: string;
    createdAt: string;
    updatedAt?: string;
    user?: {
      id: number;
      username: string;
      firstName: string;
      lastName: string;
      batch: string;
      avatar?: string;
    };
  };
  commentsCount?: number;
  viewsCount?: number;
}

export function ForumPostCard({ post, commentsCount = 0, viewsCount = 0 }: ForumPostCardProps) {
  return (
    <Card className="mb-4 hover:shadow-md transition-shadow duration-200">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-3">
          <Link href={`/forums/${post.id}`}>
            <a className="text-lg font-medium text-neutral-900 hover:text-primary">{post.title}</a>
          </Link>
          <Badge variant="outline" className="bg-primary/10 text-primary border-none">
            {post.category}
          </Badge>
        </div>
        
        <p className="text-neutral-600 mb-4 line-clamp-2">{post.content}</p>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center text-sm text-neutral-500">
            <Avatar className="h-8 w-8 mr-2">
              <AvatarImage 
                src={post.user?.avatar} 
                alt={post.user ? `${post.user.firstName} ${post.user.lastName}` : "User"} 
              />
              <AvatarFallback className="bg-neutral-300">
                {getInitials(post.user ? `${post.user.firstName} ${post.user.lastName}` : "User")}
              </AvatarFallback>
            </Avatar>
            <div>
              <div className="font-medium">
                {post.user ? `${post.user.firstName} ${post.user.lastName}` : "Anonymous"}
              </div>
              <div className="flex items-center text-xs">
                <span>{post.user?.batch || "Unknown batch"}</span>
                <span className="mx-1">•</span>
                <Calendar className="h-3 w-3 mr-1" />
                <span>{formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <span className="flex items-center text-sm text-neutral-500">
              <MessageCircle className="h-4 w-4 text-neutral-400 mr-1" />
              {commentsCount}
            </span>
            <span className="flex items-center text-sm text-neutral-500">
              <Eye className="h-4 w-4 text-neutral-400 mr-1" />
              {viewsCount}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
