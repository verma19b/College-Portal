import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";
import { FileText, Download } from "lucide-react";
import { getInitials } from "@/lib/utils";

interface ResourceCardProps {
  resource: {
    id: number;
    title: string;
    description: string;
    fileUrl: string;
    fileType: string;
    category: string;
    createdAt: string;
    user?: {
      id: number;
      username: string;
      firstName: string;
      lastName: string;
      batch: string;
      avatar?: string;
    };
  };
}

export function ResourceCard({ resource }: ResourceCardProps) {
  // Get appropriate icon based on file type
  const getFileIcon = () => {
    switch (resource.fileType) {
      case "assignment":
        return <FileText className="h-10 w-10 text-primary" />;
      case "question_bank":
        return <FileText className="h-10 w-10 text-secondary" />;
      case "note":
        return <FileText className="h-10 w-10 text-accent" />;
      default:
        return <FileText className="h-10 w-10 text-neutral-500" />;
    }
  };
  
  // Get appropriate badge color based on file type
  const getBadgeClass = () => {
    switch (resource.fileType) {
      case "assignment":
        return "bg-primary/10 text-primary";
      case "question_bank":
        return "bg-secondary/10 text-secondary";
      case "note":
        return "bg-accent/10 text-accent";
      default:
        return "bg-neutral-200 text-neutral-700";
    }
  };
  
  // Format file type for display
  const formatFileType = (fileType: string) => {
    return fileType.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };
  
  return (
    <Card className="mb-4 hover:shadow-md transition-shadow duration-200">
      <CardContent className="p-6">
        <div className="flex items-start">
          <div className="flex-shrink-0 mr-4 bg-neutral-100 p-3 rounded-md">
            {getFileIcon()}
          </div>
          
          <div className="flex-1">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-lg font-medium text-neutral-900">{resource.title}</h3>
              <Badge variant="outline" className={getBadgeClass()}>
                {formatFileType(resource.fileType)}
              </Badge>
            </div>
            
            <p className="text-neutral-600 mb-4 line-clamp-2">{resource.description}</p>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center text-sm text-neutral-500">
                <Avatar className="h-6 w-6 mr-2">
                  <AvatarImage 
                    src={resource.user?.avatar} 
                    alt={resource.user ? `${resource.user.firstName} ${resource.user.lastName}` : "User"} 
                  />
                  <AvatarFallback className="bg-neutral-300 text-xs">
                    {getInitials(resource.user ? `${resource.user.firstName} ${resource.user.lastName}` : "User")}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <span className="font-medium">
                    {resource.user ? `${resource.user.firstName} ${resource.user.lastName}` : "Anonymous"}
                  </span>
                  <span className="mx-1">•</span>
                  <span>{resource.category}</span>
                  <span className="mx-1">•</span>
                  <span>{formatDistanceToNow(new Date(resource.createdAt), { addSuffix: true })}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="px-6 py-4 bg-neutral-50 border-t">
        <Button 
          variant="outline" 
          size="sm" 
          className="ml-auto text-primary border-primary hover:bg-primary/10"
          onClick={() => window.open(resource.fileUrl, '_blank')}
        >
          <Download className="h-4 w-4 mr-2" />
          Download
        </Button>
      </CardFooter>
    </Card>
  );
}
