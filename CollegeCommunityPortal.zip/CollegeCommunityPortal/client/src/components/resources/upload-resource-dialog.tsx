import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertResourceSchema } from "@shared/schema";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Upload, Laptop, Cpu, Bolt, Wrench, Building2, Beaker, Factory } from "lucide-react";

// MANIT Bhopal departments
const departments = [
  { id: "cse", name: "Computer Science & Engineering (CSE)", icon: <Laptop className="h-4 w-4" /> },
  { id: "ece", name: "Electronics & Communication Engineering (ECE)", icon: <Cpu className="h-4 w-4" /> },
  { id: "ee", name: "Electrical Engineering (EE)", icon: <Bolt className="h-4 w-4" /> },
  { id: "me", name: "Mechanical Engineering (ME)", icon: <Wrench className="h-4 w-4" /> },
  { id: "ce", name: "Civil Engineering (CE)", icon: <Building2 className="h-4 w-4" /> },
  { id: "chem", name: "Chemical Engineering (CHEM)", icon: <Beaker className="h-4 w-4" /> },
  { id: "mme", name: "Metallurgy & Materials Engineering (MME)", icon: <Factory className="h-4 w-4" /> },
  { id: "first_year", name: "First Year (Common)", icon: <Building2 className="h-4 w-4" /> }
];

// Extend the existing schema to add validation rules
const uploadResourceSchema = insertResourceSchema.extend({
  title: z.string().min(5, "Title must be at least 5 characters"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  fileUrl: z.string().url("Must be a valid URL"),
  fileType: z.string().min(1, "Please select a file type"),
  category: z.string().min(1, "Please select a category"),
  department: z.string().min(1, "Please select a department"),
});

type UploadResourceData = z.infer<typeof uploadResourceSchema>;

// Resource types (file types)
const fileTypes = [
  "assignment",
  "question_bank",
  "note",
  "study_material",
  "lab_manual",
  "presentation",
  "previous_year_paper",
  "syllabus",
  "project_report"
];

// Resource categories specific to MANIT Bhopal
const categories = [
  // Common for all departments
  "First Year Common",
  // CSE specific
  "Programming",
  "Data Structures",
  "Algorithms",
  "Database Systems",
  "Web Development",
  "Machine Learning",
  "Computer Networks",
  "Operating Systems",
  "Software Engineering",
  // ECE & EE specific
  "Electronics",
  "Circuits",
  "Power Systems",
  "Control Systems",
  "Digital Signal Processing",
  "Microprocessors",
  // ME specific
  "Mechanical Design",
  "Thermodynamics",
  "Fluid Mechanics",
  "Manufacturing Processes",
  // CE specific
  "Structural Analysis",
  "Construction Technology",
  "Geotechnical Engineering",
  "Transportation Engineering",
  // CHEM specific
  "Chemical Processes",
  "Process Control",
  "Chemical Reaction Engineering",
  // MME specific
  "Material Science",
  "Metallurgy",
  "Non-destructive Testing",
  // Other
  "Mathematics",
  "Physics",
  "Chemistry",
  "Humanities",
  "Other"
];

export function UploadResourceDialog() {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const [selectedDepartment, setSelectedDepartment] = useState<string>("");
  
  const form = useForm<UploadResourceData>({
    resolver: zodResolver(uploadResourceSchema),
    defaultValues: {
      title: "",
      description: "",
      fileUrl: "",
      fileType: "",
      category: "",
      department: "",
      userId: 0, // This will be set by the server based on the authenticated user
    },
  });
  
  const uploadResourceMutation = useMutation({
    mutationFn: async (data: UploadResourceData) => {
      const res = await apiRequest("POST", "/api/resources", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resources"] });
      toast({
        title: "Success!",
        description: "Your resource has been uploaded.",
      });
      form.reset();
      setOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  function onSubmit(data: UploadResourceData) {
    uploadResourceMutation.mutate(data);
  }
  
  // Format options for display
  const formatOption = (option: string) => {
    return option.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };
  
  // Handle department change to filter relevant categories
  const handleDepartmentChange = (value: string) => {
    form.setValue("department", value);
    setSelectedDepartment(value);
    // Reset category when department changes
    form.setValue("category", "");
  };
  
  // Filter categories based on selected department
  const getFilteredCategories = () => {
    switch (selectedDepartment) {
      case "cse":
        return categories.filter(cat => 
          ["First Year Common", "Programming", "Data Structures", "Algorithms", 
           "Database Systems", "Web Development", "Machine Learning", 
           "Computer Networks", "Operating Systems", "Software Engineering", 
           "Mathematics", "Other"].includes(cat)
        );
      case "ece":
      case "ee":
        return categories.filter(cat => 
          ["First Year Common", "Electronics", "Circuits", "Power Systems", 
           "Control Systems", "Digital Signal Processing", "Microprocessors", 
           "Mathematics", "Physics", "Other"].includes(cat)
        );
      case "me":
        return categories.filter(cat => 
          ["First Year Common", "Mechanical Design", "Thermodynamics", 
           "Fluid Mechanics", "Manufacturing Processes", "Mathematics", 
           "Physics", "Other"].includes(cat)
        );
      case "ce":
        return categories.filter(cat => 
          ["First Year Common", "Structural Analysis", "Construction Technology", 
           "Geotechnical Engineering", "Transportation Engineering", 
           "Mathematics", "Physics", "Other"].includes(cat)
        );
      case "chem":
        return categories.filter(cat => 
          ["First Year Common", "Chemical Processes", "Process Control", 
           "Chemical Reaction Engineering", "Mathematics", "Chemistry", "Other"].includes(cat)
        );
      case "mme":
        return categories.filter(cat => 
          ["First Year Common", "Material Science", "Metallurgy", 
           "Non-destructive Testing", "Mathematics", "Chemistry", "Physics", "Other"].includes(cat)
        );
      case "first_year":
        return categories.filter(cat => 
          ["First Year Common", "Mathematics", "Physics", "Chemistry", 
           "Programming", "Humanities", "Other"].includes(cat)
        );
      default:
        return categories;
    }
  };
  
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2">
          <Upload className="h-4 w-4" />
          Upload Resource
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Upload MANIT Bhopal Resource</DialogTitle>
          <DialogDescription>
            Share study materials, assignments, or question banks with your peers at MANIT Bhopal.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 py-4">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter a descriptive title" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="department"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Department</FormLabel>
                  <Select 
                    onValueChange={handleDepartmentChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a department" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {departments.map(dept => (
                        <SelectItem key={dept.id} value={dept.id}>
                          <div className="flex items-center gap-2">
                            {dept.icon}
                            <span>{dept.name}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="fileType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>File Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a file type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {fileTypes.map(type => (
                          <SelectItem key={type} value={type}>
                            {formatOption(type)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category/Subject</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      defaultValue={field.value}
                      disabled={!selectedDepartment}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder={selectedDepartment ? "Select a category" : "Select department first"} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {getFilteredCategories().map(category => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Describe your resource..." 
                      className="min-h-[100px]" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="fileUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>File URL</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Enter the URL of your file (Google Drive, Dropbox, etc.)" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setOpen(false)}
                className="mt-2"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={uploadResourceMutation.isPending}
                className="mt-2"
              >
                {uploadResourceMutation.isPending ? "Uploading..." : "Upload"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
