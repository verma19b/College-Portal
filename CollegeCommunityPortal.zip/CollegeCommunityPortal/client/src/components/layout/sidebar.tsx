import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getInitials } from "@/lib/utils";
import {
  LayoutDashboard,
  MessageSquare,
  FileText,
  Calendar,
  Users,
  CheckSquare,
  LineChart,
  AlignJustify,
  Bus,
  Map,
} from "lucide-react";
import { cn } from "@/lib/utils";

export function Sidebar() {
  const { user } = useAuth();
  const [location] = useLocation();

  if (!user) return null;

  const isActive = (path: string) => location === path;

  const navigationItems = [
    {
      label: "Main",
      items: [
        { href: "/", icon: LayoutDashboard, text: "Dashboard" },
        { href: "/forums", icon: MessageSquare, text: "Forums" },
        { href: "/resources", icon: FileText, text: "Resources" },
        { href: "/events", icon: Calendar, text: "Events" },
        { href: "/connect", icon: Users, text: "Connect" },
      ],
    },
    {
      label: "Academics",
      items: [
        { href: "/attendance", icon: CheckSquare, text: "Attendance" },
        { href: "/progress", icon: LineChart, text: "Progress" },
        { href: "/assignments", icon: AlignJustify, text: "Assignments" },
      ],
    },
    {
      label: "Campus",
      items: [
        { href: "/bus-tracker", icon: Bus, text: "Bus Tracker" },
        { href: "/campus-map", icon: Map, text: "Campus Map" },
      ],
    },
  ];

  return (
    <aside className="hidden md:flex md:flex-shrink-0 bg-white border-r border-neutral-200">
      <div className="w-64 flex flex-col">
        {/* Navigation */}
        <nav className="flex-1 pt-4 pb-4 overflow-y-auto">
          {navigationItems.map((section) => (
            <div key={section.label} className="px-4 mb-6">
              <h2 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider">
                {section.label}
              </h2>
              <div className="mt-2 space-y-1">
                {section.items.map((item) => {
                  const active = isActive(item.href);
                  return (
                    <Link key={item.href} href={item.href}>
                      <a
                        className={cn(
                          "group flex items-center px-2 py-2 text-sm font-medium rounded-md",
                          {
                            "bg-primary/10 text-primary": active,
                            "text-neutral-700 hover:bg-neutral-100": !active,
                          }
                        )}
                      >
                        <item.icon
                          className={cn("mr-3 h-5 w-5", {
                            "text-primary": active,
                            "text-neutral-500": !active,
                          })}
                        />
                        {item.text}
                      </a>
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* User info at bottom */}
        <div className="flex-shrink-0 flex border-t border-neutral-200 p-4">
          <div className="flex-shrink-0 w-full group block">
            <div className="flex items-center">
              <Avatar>
                <AvatarImage src={user.avatar} alt={`${user.firstName} ${user.lastName}`} />
                <AvatarFallback className="bg-neutral-300">
                  {getInitials(`${user.firstName} ${user.lastName}`)}
                </AvatarFallback>
              </Avatar>
              <div className="ml-3">
                <p className="text-sm font-medium text-neutral-700">
                  {user.firstName} {user.lastName}
                </p>
                <p className="text-xs font-medium text-neutral-500">
                  ID: {user.studentId}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
