import { ReactNode } from "react";
import { Header } from "@/components/layout/header";
import { Sidebar } from "@/components/layout/sidebar";
import { MobileNav } from "@/components/layout/mobile-nav";

interface AppShellProps {
  children: ReactNode;
}

export function AppShell({ children }: AppShellProps) {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <div className="flex-1 flex overflow-hidden">
        <Sidebar />

        <main className="flex-1 overflow-y-auto bg-neutral-100 pb-16 md:pb-0">
          <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
            {children}
          </div>

          {/* Footer with copyright */}
          <footer className="mt-auto py-3 px-6 border-t bg-white/80 backdrop-blur-sm">
            <div className="max-w-7xl mx-auto flex justify-between items-center">
              <div className="text-sm text-gray-500">
                © {new Date().getFullYear()} Campus Connect. All rights reserved.
              </div>
              <div className="text-sm font-medium text-primary">
                Developed by Bharat Verma
              </div>
            </div>
          </footer>
        </main>
      </div>

      <MobileNav />
    </div>
  );
}