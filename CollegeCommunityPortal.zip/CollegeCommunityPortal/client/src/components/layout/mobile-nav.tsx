import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  MessageSquare,
  FileText,
  Calendar,
  Users,
} from "lucide-react";
import { cn } from "@/lib/utils";

export function MobileNav() {
  const [location] = useLocation();
  
  const isActive = (path: string) => location === path;
  
  const navItems = [
    { href: "/", icon: LayoutDashboard, text: "Home" },
    { href: "/forums", icon: MessageSquare, text: "Forums" },
    { href: "/resources", icon: FileText, text: "Resources" },
    { href: "/events", icon: Calendar, text: "Events" },
    { href: "/connect", icon: Users, text: "Connect" },
  ];

  return (
    <div className="md:hidden bg-white border-t border-neutral-200 fixed bottom-0 w-full z-10">
      <div className="grid grid-cols-5">
        {navItems.map((item) => {
          const active = isActive(item.href);
          return (
            <Link key={item.href} href={item.href}>
              <a className={cn("flex flex-col items-center justify-center py-2", {
                "text-primary": active,
                "text-neutral-500": !active,
              })}>
                <item.icon className="h-5 w-5" />
                <span className="text-xs mt-1">{item.text}</span>
              </a>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
