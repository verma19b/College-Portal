import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { SearchIcon, BellIcon } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getInitials } from "@/lib/utils";

export function Header() {
  const { user } = useAuth();

  if (!user) return null;

  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center h-16">
        <div className="flex items-center">
          {/* Logo */}
          <Link href="/">
            <div className="flex-shrink-0 flex items-center cursor-pointer">
              <div className="h-10 w-10 rounded-md bg-primary flex items-center justify-center text-white font-bold text-lg">
                CC
              </div>
              <span className="ml-2 font-heading font-semibold text-lg text-neutral-900 hidden md:block">
                Campus Connect
              </span>
            </div>
          </Link>
        </div>
        
        {/* Search bar */}
        <div className="hidden md:block mx-4 flex-1 max-w-md">
          <div className="relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <SearchIcon className="h-4 w-4 text-neutral-400" />
            </div>
            <Input 
              type="text" 
              className="block w-full pl-10 pr-3 py-2 border border-neutral-200 rounded-md leading-5 bg-neutral-100 placeholder-neutral-500 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm" 
              placeholder="Search resources, events, forums..." 
            />
          </div>
        </div>
        
        {/* User menu */}
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="icon" className="bg-neutral-100 p-1 rounded-full text-neutral-500 hover:text-neutral-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary">
            <BellIcon className="h-5 w-5" />
          </Button>
          <div className="relative">
            <div className="flex items-center">
              <Avatar>
                <AvatarImage src={user.avatar} alt={`${user.firstName} ${user.lastName}`} />
                <AvatarFallback className="bg-neutral-300">
                  {getInitials(`${user.firstName} ${user.lastName}`)}
                </AvatarFallback>
              </Avatar>
              <span className="hidden lg:inline-block ml-2 text-sm font-medium text-neutral-700">
                {user.firstName} {user.lastName}
              </span>
              <span className="hidden lg:inline-block ml-1 text-xs text-primary font-semibold rounded-full bg-primary/10 px-2 py-0.5">
                {user.batch}
              </span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
