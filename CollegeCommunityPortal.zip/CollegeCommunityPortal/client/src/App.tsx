import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import DashboardPage from "@/pages/dashboard-page";
import ForumsPage from "@/pages/forums-page";
import ResourcesPage from "@/pages/resources-page";
import EventsPage from "@/pages/events-page";
import ConnectPage from "@/pages/connect-page";
import AttendancePage from "@/pages/attendance-page";
import ProgressPage from "@/pages/progress-page";
import AssignmentsPage from "@/pages/assignments-page";
import BusTrackerPage from "@/pages/bus-tracker-page";
import CampusMapPage from "@/pages/campus-map-page";
import { ProtectedRoute } from "./lib/protected-route";
import { AuthProvider } from "@/hooks/use-auth";

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/" component={DashboardPage} />
      <ProtectedRoute path="/forums" component={ForumsPage} />
      <ProtectedRoute path="/resources" component={ResourcesPage} />
      <ProtectedRoute path="/events" component={EventsPage} />
      <ProtectedRoute path="/connect" component={ConnectPage} />
      <ProtectedRoute path="/attendance" component={AttendancePage} />
      <ProtectedRoute path="/progress" component={ProgressPage} />
      <ProtectedRoute path="/assignments" component={AssignmentsPage} />
      <ProtectedRoute path="/bus-tracker" component={BusTrackerPage} />
      <ProtectedRoute path="/campus-map" component={CampusMapPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
